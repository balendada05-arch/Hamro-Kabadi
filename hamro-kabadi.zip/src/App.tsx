/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  CheckCircle2,
  Compass,
  Download,
  Edit3,
  Handshake,
  LogOut,
  MapPin,
  MessageSquare,
  Navigation,
  PhoneCall,
  Plus,
  Receipt,
  Search,
  SlidersHorizontal,
  Trash2,
  TrendingUp,
  User,
  X,
} from 'lucide-react';
import {
  AppNotification,
  ChatMessage,
  ChatThread,
  GeoPoint,
  MaterialCategory,
  MaterialPriceRate,
  ScrapListing,
  ScrapTransaction,
  TransactionStatus,
  UserAccount,
  UserReview,
  UserRole,
} from './types';
import {
  INITIAL_LISTINGS,
  INITIAL_MARKET_PRICES,
  INITIAL_MESSAGES,
  INITIAL_NOTIFICATIONS,
  INITIAL_REVIEWS,
  INITIAL_THREADS,
  INITIAL_TRANSACTIONS,
  INITIAL_USERS,
} from './data/initialData';
import { calculateDistanceKm, formatRs } from './utils/cryptoAndGeo';
import { ResilientImage } from './components/ResilientImage';
import { InteractiveMap } from './components/InteractiveMap';
import { AuthScreen } from './components/AuthScreen';
import { MarketPriceView } from './components/MarketPriceView';
import { SellerListingModal } from './components/SellerListingModal';
import { ChatAndNegotiation } from './components/ChatAndNegotiation';
import {
  TransactionsView,
  UserProfileModal,
} from './components/TransactionAndProfileModals';
import { PWAInstallModal } from './components/PWAInstallModal';

type MainTab = 'home' | 'map' | 'rates' | 'messages' | 'transactions';
type SortOption = 'distance' | 'newest' | 'lowest_price' | 'highest_quantity';

const STORAGE_KEYS = {
  USERS: 'hk_users_v1',
  CURRENT_USER_ID: 'hk_current_user_id_v1',
  LISTINGS: 'hk_listings_v1',
  MARKET_RATES: 'hk_market_rates_v1',
  THREADS: 'hk_threads_v1',
  MESSAGES: 'hk_messages_v1',
  TRANSACTIONS: 'hk_transactions_v1',
  REVIEWS: 'hk_reviews_v1',
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  // Persistent State
  const [users, setUsers] = useState<UserAccount[]>(() =>
    loadFromStorage(STORAGE_KEYS.USERS, INITIAL_USERS)
  );
  const [currentUserId, setCurrentUserId] = useState<string | null>(() =>
    loadFromStorage<string | null>(STORAGE_KEYS.CURRENT_USER_ID, 'HK-1001')
  );
  const [listings, setListings] = useState<ScrapListing[]>(() =>
    loadFromStorage(STORAGE_KEYS.LISTINGS, INITIAL_LISTINGS)
  );
  const [marketRates, setMarketRates] = useState<MaterialPriceRate[]>(() =>
    loadFromStorage(STORAGE_KEYS.MARKET_RATES, INITIAL_MARKET_PRICES)
  );
  const [threads, setThreads] = useState<ChatThread[]>(() =>
    loadFromStorage(STORAGE_KEYS.THREADS, INITIAL_THREADS)
  );
  const [messages, setMessages] = useState<ChatMessage[]>(() =>
    loadFromStorage(STORAGE_KEYS.MESSAGES, INITIAL_MESSAGES)
  );
  const [transactions, setTransactions] = useState<ScrapTransaction[]>(() =>
    loadFromStorage(STORAGE_KEYS.TRANSACTIONS, INITIAL_TRANSACTIONS)
  );
  const [reviews, setReviews] = useState<UserReview[]>(() =>
    loadFromStorage(STORAGE_KEYS.REVIEWS, INITIAL_REVIEWS)
  );
  const [notifications, setNotifications] = useState<AppNotification[]>(
    INITIAL_NOTIFICATIONS
  );

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
      localStorage.setItem(STORAGE_KEYS.CURRENT_USER_ID, JSON.stringify(currentUserId));
      localStorage.setItem(STORAGE_KEYS.LISTINGS, JSON.stringify(listings));
      localStorage.setItem(STORAGE_KEYS.MARKET_RATES, JSON.stringify(marketRates));
      localStorage.setItem(STORAGE_KEYS.THREADS, JSON.stringify(threads));
      localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
      localStorage.setItem(STORAGE_KEYS.REVIEWS, JSON.stringify(reviews));
    } catch {
      // Ignore storage quota errors
    }
  }, [
    users,
    currentUserId,
    listings,
    marketRates,
    threads,
    messages,
    transactions,
    reviews,
  ]);

  const currentUser = useMemo(
    () => users.find((u) => u.id === currentUserId) || null,
    [users, currentUserId]
  );

  // Navigation & UI Modals State
  const [activeTab, setActiveTab] = useState<MainTab>('home');
  const [selectedThreadId, setSelectedThreadId] = useState<string | null>(
    INITIAL_THREADS[0]?.id || null
  );
  const [selectedListing, setSelectedListing] = useState<ScrapListing | null>(null);
  const [activePhotoIndex, setActivePhotoIndex] = useState<number>(0);
  const [directOfferPrice, setDirectOfferPrice] = useState<string>('');
  const [pickupScheduleInput, setPickupScheduleInput] = useState<string>(
    'Tomorrow, 10:30 AM'
  );

  // Seller Create/Edit Modal
  const [isSellerModalOpen, setIsSellerModalOpen] = useState(false);
  const [editingListing, setEditingListing] = useState<ScrapListing | null>(null);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // Profile Inspection / Edit Modal
  const [inspectingUserId, setInspectingUserId] = useState<string | null>(null);

  // Notifications Drawer
  const [showNotifications, setShowNotifications] = useState(false);

  // Call Dialer Modal
  const [callTarget, setCallTarget] = useState<{
    name: string;
    phone: string;
    roleLabel: string;
  } | null>(null);

  // Active Navigation Target on Map
  const [navigationTarget, setNavigationTarget] = useState<{
    title: string;
    destination: GeoPoint;
  } | null>(null);

  // Search & Filter State (#9)
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<MaterialCategory | 'All'>('All');
  const [maxPricePerKg, setMaxPricePerKg] = useState<number>(1000);
  const [minWeightKg, setMinWeightKg] = useState<number>(0);
  const [radiusKm, setRadiusKm] = useState<number>(10);
  const [sortBy, setSortBy] = useState<SortOption>('distance');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Filtered & Sorted Listings (#7, #8, #9)
  const enrichedListings = useMemo(() => {
    const origin = currentUser?.location || {
      lat: 27.6915,
      lng: 85.342,
      address: 'New Baneshwor, Kathmandu',
    };
    return listings.map((item) => ({
      ...item,
      distanceKm: calculateDistanceKm(origin, item.location),
    }));
  }, [listings, currentUser]);

  const filteredListings = useMemo(() => {
    return enrichedListings
      .filter((item) => {
        if (selectedCategory !== 'All' && item.category !== selectedCategory) {
          return false;
        }
        if (item.askingPricePerKg > maxPricePerKg) return false;
        if (item.weightKg < minWeightKg) return false;
        if (radiusKm < 100 && item.distanceKm > radiusKm) return false;
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = item.title.toLowerCase().includes(q);
          const matchCat = item.category.toLowerCase().includes(q);
          const matchSeller = item.sellerName.toLowerCase().includes(q);
          const matchAddr = item.location.address.toLowerCase().includes(q);
          if (!matchTitle && !matchCat && !matchSeller && !matchAddr) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'distance') return a.distanceKm - b.distanceKm;
        if (sortBy === 'newest') {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        }
        if (sortBy === 'lowest_price') return a.askingPricePerKg - b.askingPricePerKg;
        if (sortBy === 'highest_quantity') return b.weightKg - a.weightKg;
        return 0;
      });
  }, [
    enrichedListings,
    selectedCategory,
    maxPricePerKg,
    minWeightKg,
    radiusKm,
    searchQuery,
    sortBy,
  ]);

  // Recent Listings sorted strictly by timestamp (#13)
  const recentListings = useMemo(() => {
    return [...enrichedListings]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 3);
  }, [enrichedListings]);

  // Handlers
  const handleUpdateUserLocation = (loc: GeoPoint, permissionGranted: boolean) => {
    if (!currentUser) return;
    setUsers((prev) =>
      prev.map((u) =>
        u.id === currentUser.id
          ? { ...u, location: loc, locationPermissionGranted: permissionGranted }
          : u
      )
    );
  };

  const handleToggleLiveSharing = (enabled: boolean) => {
    if (!currentUser) return;
    setUsers((prev) =>
      prev.map((u) =>
        u.id === currentUser.id ? { ...u, liveLocationSharing: enabled } : u
      )
    );
  };

  const handleRoleSwitch = (newRole: UserRole) => {
    if (!currentUser) return;
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? { ...u, role: newRole } : u))
    );
  };

  const handleSaveListing = (saved: ScrapListing, isEdit: boolean) => {
    if (isEdit) {
      setListings((prev) => prev.map((l) => (l.id === saved.id ? saved : l)));
    } else {
      setListings((prev) => [saved, ...prev]);
    }
  };

  const handleDeleteListing = (listingId: string) => {
    setListings((prev) => prev.filter((l) => l.id !== listingId));
    if (selectedListing?.id === listingId) setSelectedListing(null);
  };

  const handleMarkAsSold = (listing: ScrapListing) => {
    setListings((prev) =>
      prev.map((l) => (l.id === listing.id ? { ...l, status: 'Sold' } : l))
    );
    if (selectedListing?.id === listing.id) {
      setSelectedListing({ ...listing, status: 'Sold' });
    }
  };

  const handleUpdateMarketRate = (
    category: MaterialCategory,
    marketPricePerKg: number,
    suggestedBuyingPrice: number,
    suggestedSellingPrice: number
  ) => {
    const today = new Date().toISOString().split('T')[0];
    setMarketRates((prev) =>
      prev.map((r) => {
        if (r.category !== category) return r;
        return {
          ...r,
          marketPricePerKg,
          suggestedBuyingPrice,
          suggestedSellingPrice,
          updatedAt: today,
          history: [
            ...r.history,
            {
              date: today,
              marketPricePerKg,
              suggestedBuyingPrice,
              suggestedSellingPrice,
              updatedBy: currentUser?.fullName.split(' ')[0] || 'Admin',
            },
          ],
        };
      })
    );

    // Also update market benchmark shown on existing listings of that category
    setListings((prev) =>
      prev.map((l) => (l.category === category ? { ...l, marketPricePerKg } : l))
    );

    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}`,
        userId: currentUser?.id || 'HK-1001',
        title: `Market Price Updated: ${category}`,
        body: `${category} benchmark set to ${formatRs(
          marketPricePerKg
        )}/KG (Suggested Seller: ${formatRs(suggestedSellingPrice)}/KG).`,
        type: 'price_update',
        read: false,
        createdAt: 'Just now',
      },
      ...prev,
    ]);
  };

  const handleStartChatOrNegotiation = (
    listing: ScrapListing,
    initialOfferPerKg?: number
  ) => {
    if (!currentUser) return;
    let thread = threads.find(
      (t) =>
        t.listingId === listing.id &&
        (t.buyerId === currentUser.id || t.sellerId === currentUser.id)
    );

    if (!thread) {
      const newThread: ChatThread = {
        id: `THD-${Date.now()}`,
        listingId: listing.id,
        listingTitle: listing.title,
        listingCategory: listing.category,
        listingWeightKg: listing.weightKg,
        listingAskingPricePerKg: listing.askingPricePerKg,
        buyerId: currentUser.id,
        buyerName: currentUser.fullName,
        buyerPhone: currentUser.phone,
        sellerId: listing.sellerId,
        sellerName: listing.sellerName,
        sellerPhone: listing.sellerPhone,
        currentAgreedPricePerKg: initialOfferPerKg || listing.askingPricePerKg,
        pickupLocation: listing.location,
        updatedAt: new Date().toISOString(),
      };
      setThreads((prev) => [newThread, ...prev]);
      thread = newThread;
    }

    if (initialOfferPerKg && initialOfferPerKg > 0) {
      const total = Math.round(initialOfferPerKg * listing.weightKg);
      const newMsg: ChatMessage = {
        id: `MSG-${Date.now()}`,
        threadId: thread.id,
        senderId: currentUser.id,
        senderName: currentUser.fullName,
        senderRole: currentUser.role,
        text: `Proposed price offer for ${listing.title}: ${formatRs(
          initialOfferPerKg
        )}/KG (Total: ${formatRs(total)} for ${listing.weightKg} KG).`,
        offeredPricePerKg: initialOfferPerKg,
        offerStatus: 'pending',
        createdAt: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, newMsg]);

      // Create or update Negotiating transaction
      const existingTxn = transactions.find((tx) => tx.listingId === listing.id);
      if (!existingTxn) {
        const negotiatingTxn: ScrapTransaction = {
          id: `TXN-${Math.floor(5010 + Math.random() * 4900)}`,
          listingId: listing.id,
          listingTitle: listing.title,
          category: listing.category,
          weightKg: listing.weightKg,
          agreedPricePerKg: initialOfferPerKg,
          totalAgreedAmount: total,
          buyerId: currentUser.id,
          buyerName: currentUser.fullName,
          buyerPhone: currentUser.phone,
          sellerId: listing.sellerId,
          sellerName: listing.sellerName,
          sellerPhone: listing.sellerPhone,
          pickupLocation: listing.location,
          scheduledPickupTime: pickupScheduleInput,
          status: TransactionStatus.NEGOTIATING,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        setTransactions((prev) => [negotiatingTxn, ...prev]);
      }
    }

    setSelectedThreadId(thread.id);
    setSelectedListing(null);
    setActiveTab('messages');
  };

  const handleSendMessage = (
    threadId: string,
    text: string,
    options?: {
      photoUrl?: string;
      offeredPricePerKg?: number;
      sharedLocation?: GeoPoint;
      isFinalConfirmation?: boolean;
    }
  ) => {
    if (!currentUser) return;
    const newMsg: ChatMessage = {
      id: `MSG-${Date.now()}`,
      threadId,
      senderId: currentUser.id,
      senderName: currentUser.fullName,
      senderRole: currentUser.role,
      text,
      photoUrl: options?.photoUrl,
      offeredPricePerKg: options?.offeredPricePerKg,
      sharedLocation: options?.sharedLocation,
      isFinalConfirmation: options?.isFinalConfirmation,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, newMsg]);

    if (options?.offeredPricePerKg) {
      setThreads((prev) =>
        prev.map((t) =>
          t.id === threadId
            ? {
                ...t,
                currentAgreedPricePerKg: options.offeredPricePerKg,
                updatedAt: new Date().toISOString(),
              }
            : t
        )
      );
    }
  };

  const handleConfirmFinalPrice = (
    thread: ChatThread,
    agreedPricePerKg: number
  ) => {
    const totalAgreedAmount = Math.round(agreedPricePerKg * thread.listingWeightKg);

    // Record confirmation message in chat
    handleSendMessage(
      thread.id,
      `Final price confirmed at ${formatRs(
        agreedPricePerKg
      )}/KG (Total Agreed Amount: ${formatRs(
        totalAgreedAmount
      )}). Transaction moved to Confirmed for pickup at ${thread.pickupLocation.address}.`,
      { isFinalConfirmation: true, offeredPricePerKg: agreedPricePerKg }
    );

    // Update or create Transaction
    const existing = transactions.find((tx) => tx.listingId === thread.listingId);
    if (existing) {
      setTransactions((prev) =>
        prev.map((tx) =>
          tx.id === existing.id
            ? {
                ...tx,
                agreedPricePerKg,
                totalAgreedAmount,
                status: TransactionStatus.CONFIRMED,
                updatedAt: new Date().toISOString(),
              }
            : tx
        )
      );
    } else {
      const created: ScrapTransaction = {
        id: `TXN-${Math.floor(5010 + Math.random() * 4900)}`,
        listingId: thread.listingId,
        listingTitle: thread.listingTitle,
        category: thread.listingCategory,
        weightKg: thread.listingWeightKg,
        agreedPricePerKg,
        totalAgreedAmount,
        buyerId: thread.buyerId,
        buyerName: thread.buyerName,
        buyerPhone: thread.buyerPhone,
        sellerId: thread.sellerId,
        sellerName: thread.sellerName,
        sellerPhone: thread.sellerPhone,
        pickupLocation: thread.pickupLocation,
        scheduledPickupTime: pickupScheduleInput || 'Today, 4:00 PM',
        status: TransactionStatus.CONFIRMED,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      setTransactions((prev) => [created, ...prev]);
    }

    setListings((prev) =>
      prev.map((l) =>
        l.id === thread.listingId ? { ...l, status: 'Negotiating' } : l
      )
    );

    setActiveTab('transactions');
  };

  const handleUpdateTransactionStatus = (
    transactionId: string,
    nextStatus: TransactionStatus
  ) => {
    const target = transactions.find((t) => t.id === transactionId);
    setTransactions((prev) =>
      prev.map((t) =>
        t.id === transactionId
          ? { ...t, status: nextStatus, updatedAt: new Date().toISOString() }
          : t
      )
    );

    if (nextStatus === TransactionStatus.COMPLETED && target) {
      setListings((prev) =>
        prev.map((l) =>
          l.id === target.listingId ? { ...l, status: 'Sold' } : l
        )
      );
      setUsers((prev) =>
        prev.map((u) =>
          u.id === target.buyerId || u.id === target.sellerId
            ? { ...u, completedTransactions: u.completedTransactions + 1 }
            : u
        )
      );
    }
  };

  const handleCancelTransaction = (transactionId: string, reason: string) => {
    setTransactions((prev) =>
      prev.map((t) =>
        t.id === transactionId
          ? {
              ...t,
              status: TransactionStatus.CANCELLED,
              cancelledBy: currentUser?.fullName || 'User',
              cancelReason: reason,
              updatedAt: new Date().toISOString(),
            }
          : t
      )
    );
  };

  const handleSubmitReview = (
    transaction: ScrapTransaction,
    rating: number,
    comment: string
  ) => {
    if (!currentUser) return;
    const targetUserId =
      currentUser.id === transaction.buyerId
        ? transaction.sellerId
        : transaction.buyerId;

    const newRev: UserReview = {
      id: `REV-${Date.now()}`,
      reviewerId: currentUser.id,
      reviewerName: currentUser.fullName,
      reviewerRole: currentUser.role,
      targetUserId,
      transactionId: transaction.id,
      rating,
      comment,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setReviews((prev) => [newRev, ...prev]);

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id !== targetUserId) return u;
        const newCount = u.reviewCount + 1;
        const avg = Number(
          ((u.rating * u.reviewCount + rating) / newCount).toFixed(1)
        );
        return { ...u, rating: avg, reviewCount: newCount };
      })
    );
  };

  // If signed out, render full Login / Registration / Forgot Password screen (#1, #2, #3)
  if (!currentUser) {
    return (
      <AuthScreen
        users={users}
        onLoginSuccess={(u) => setCurrentUserId(u.id)}
        onRegisterUser={(newUser) => {
          setUsers((prev) => [...prev, newUser]);
          setCurrentUserId(newUser.id);
        }}
        onResetPassword={(phone, newPasswordHash, newSalt) => {
          setUsers((prev) =>
            prev.map((u) =>
              u.phone.trim() === phone
                ? { ...u, passwordHash: newPasswordHash, salt: newSalt }
                : u
            )
          );
        }}
      />
    );
  }

  const unreadNotifCount = notifications.filter((n) => !n.read).length;
  const inspectedUser = users.find((u) => u.id === inspectingUserId) || null;

  return (
    <div className="min-h-screen bg-[#F6F7F5] text-stone-900 pb-20 md:pb-12">
      {/* Top Bar Contract: Strictly 1 row, 3 zones (Brand wordmark — 5 Nav links — 2 Actions) */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-stone-200/90 px-4 sm:px-8 h-14 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => setActiveTab('home')}
          className="font-display text-lg font-bold tracking-tight text-stone-900 whitespace-nowrap"
        >
          Hamro Kabadi
        </button>

        {/* Zone 2: 5 clean text navigation links */}
        <nav
          className="hidden md:flex items-center gap-6 text-sm font-medium text-stone-600"
          aria-label="Primary"
        >
          {[
            { id: 'home', label: 'Marketplace' },
            { id: 'map', label: 'Live Map' },
            { id: 'rates', label: 'Market Rates' },
            { id: 'messages', label: 'Messages' },
            { id: 'transactions', label: 'Transactions' },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id as MainTab)}
              className={`py-1 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === item.id
                  ? 'text-stone-950 font-semibold border-b-2 border-emerald-900'
                  : 'hover:text-stone-950'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: 2 primary actions */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              setEditingListing(null);
              setIsSellerModalOpen(true);
            }}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-emerald-900 hover:bg-emerald-800 rounded-xl transition-colors whitespace-nowrap shrink-0 min-h-[38px]"
          >
            + Sell Scrap
          </button>

          <button
            type="button"
            onClick={() => setInspectingUserId(currentUser.id)}
            className="px-3 py-2 text-xs font-medium text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors whitespace-nowrap shrink-0 min-h-[38px]"
          >
            {currentUser.fullName.split(' ')[0]} ({currentUser.role})
          </button>
        </div>
      </header>

      {/* Main Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-8 pt-6 space-y-8">
        {/* Dashboard Context Bar: Location, Role Switcher, Notifications, Sign Out */}
        <section className="bg-white border border-stone-200/90 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3 text-xs text-stone-600">
            <div className="flex items-center gap-1.5 font-medium text-stone-900">
              <MapPin className="w-4 h-4 text-emerald-800 shrink-0" />
              <span>{currentUser.location.address}</span>
            </div>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              User ID: {currentUser.id} (@{currentUser.userId})
            </span>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => setActiveTab('map')}
              className="text-emerald-800 font-semibold hover:underline"
            >
              Change GPS / Radius ({radiusKm === 100 ? 'All' : `${radiusKm} KM`})
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Instant Role Mode Switcher so evaluator can test Buyer, Seller & Admin flows seamlessly */}
            <div
              className="flex items-center gap-1 p-1 bg-stone-100 rounded-xl"
              role="group"
              aria-label="Account role mode"
            >
              {[UserRole.BUYER, UserRole.SELLER, UserRole.ADMIN].map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => handleRoleSwitch(r)}
                  className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                    currentUser.role === r
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {r} Mode
                </button>
              ))}
            </div>

            {/* Notification Bell */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setShowNotifications(!showNotifications);
                  setNotifications((prev) =>
                    prev.map((n) => ({ ...n, read: true }))
                  );
                }}
                aria-label="Notifications"
                className="w-9 h-9 rounded-xl bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-800 relative"
              >
                <Bell className="w-4 h-4" />
                {unreadNotifCount > 0 && (
                  <span className="w-2 h-2 rounded-full bg-emerald-700 absolute top-2 right-2" />
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white border border-stone-200 rounded-2xl shadow-xl p-4 z-40 space-y-3">
                  <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                    <span className="text-xs font-bold text-stone-900">
                      Notifications
                    </span>
                    <button
                      type="button"
                      onClick={() => setShowNotifications(false)}
                      className="text-xs text-stone-500 hover:text-stone-900"
                    >
                      Close
                    </button>
                  </div>
                  <div className="space-y-2.5 max-h-60 overflow-y-auto">
                    {notifications.map((n) => (
                      <div
                        key={n.id}
                        className="text-xs border-b border-stone-100 last:border-none pb-2"
                      >
                        <div className="font-semibold text-stone-900">{n.title}</div>
                        <p className="text-stone-600 mt-0.5">{n.body}</p>
                        <span className="text-[10px] text-stone-400">{n.createdAt}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Download / Install App Button */}
            <button
              type="button"
              onClick={() => setIsDownloadModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-100 hover:bg-emerald-200 rounded-xl transition-colors min-h-[36px]"
              title="Download or Install Hamro Kabadi"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download App</span>
            </button>

            {/* Sign Out Button to test Login / Registration / Forgot Password */}
            <button
              type="button"
              onClick={() => setCurrentUserId(null)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-stone-700 hover:text-red-800 bg-stone-100 hover:bg-red-50 rounded-xl transition-colors min-h-[36px]"
              title="Sign Out to Login Screen"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Sign Out</span>
            </button>
          </div>
        </section>

        {/* TAB 1: HOME DASHBOARD & NEARBY KABADI MARKETPLACE */}
        {activeTab === 'home' && (
          <div className="space-y-10">
            {/* Search & Filters Section (#9 & #14) */}
            <section className="bg-white border border-stone-200/90 rounded-2xl p-5 space-y-4">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search scrap material (Iron, Copper, Cardboard), seller name, or location..."
                    className="w-full pl-10 pr-4 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:outline-none focus:bg-white focus:border-emerald-900 min-h-[44px]"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  {/* Sort Selector */}
                  <select
                    aria-label="Sort listings"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as SortOption)}
                    className="px-3.5 py-2.5 text-xs font-semibold bg-stone-50 border border-stone-300 rounded-xl text-stone-800 focus:outline-none focus:border-emerald-900 min-h-[44px]"
                  >
                    <option value="distance">Sort: Nearby First</option>
                    <option value="newest">Sort: Newest Listings</option>
                    <option value="lowest_price">Sort: Lowest Price / KG</option>
                    <option value="highest_quantity">Sort: Highest Quantity (KG)</option>
                  </select>

                  {/* Distance Radius Filter */}
                  <select
                    aria-label="Distance filter"
                    value={radiusKm}
                    onChange={(e) => setRadiusKm(Number(e.target.value))}
                    className="px-3.5 py-2.5 text-xs font-semibold bg-stone-50 border border-stone-300 rounded-xl text-stone-800 focus:outline-none focus:border-emerald-900 min-h-[44px] font-mono tabular-nums"
                  >
                    <option value={2}>Within 2 KM</option>
                    <option value={5}>Within 5 KM</option>
                    <option value={10}>Within 10 KM</option>
                    <option value={25}>Within 25 KM</option>
                    <option value={100}>All Distances</option>
                  </select>

                  <button
                    type="button"
                    onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                    className={`inline-flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-semibold rounded-xl border transition-colors min-h-[44px] ${
                      showAdvancedFilters
                        ? 'bg-stone-900 text-white border-stone-900'
                        : 'bg-white text-stone-700 border-stone-300 hover:border-stone-900'
                    }`}
                  >
                    <SlidersHorizontal className="w-3.5 h-3.5" />
                    <span>Price &amp; Weight</span>
                  </button>
                </div>
              </div>

              {/* Material Category Filter Bar (All 11 Categories) */}
              <div
                className="flex items-center gap-1.5 overflow-x-auto pb-1"
                role="group"
                aria-label="Filter by material category"
              >
                {(['All', ...Object.values(MaterialCategory)] as const).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 min-h-[36px] ${
                      selectedCategory === cat
                        ? 'bg-emerald-900 text-white'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>

              {/* Collapsible Price & Weight Range Filters */}
              {showAdvancedFilters && (
                <div className="pt-3 border-t border-stone-200/80 grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Max Asking Price: <span className="font-mono">{formatRs(maxPricePerKg)}/KG</span>
                    </label>
                    <input
                      type="range"
                      min={15}
                      max={1000}
                      step={5}
                      value={maxPricePerKg}
                      onChange={(e) => setMaxPricePerKg(Number(e.target.value))}
                      className="w-full accent-emerald-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">
                      Minimum Weight: <span className="font-mono">{minWeightKg} KG</span>
                    </label>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      step={5}
                      value={minWeightKg}
                      onChange={(e) => setMinWeightKg(Number(e.target.value))}
                      className="w-full accent-emerald-900"
                    />
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedCategory('All');
                        setMaxPricePerKg(1000);
                        setMinWeightKg(0);
                        setRadiusKm(100);
                        setSearchQuery('');
                        setSortBy('distance');
                      }}
                      className="text-xs font-semibold text-stone-600 hover:text-stone-900 underline"
                    >
                      Reset All Filters
                    </button>
                  </div>
                </div>
              )}
            </section>

            {/* Nearby Kabadi Listings Section (#8) */}
            <section className="space-y-4">
              <div className="flex flex-wrap items-end justify-between gap-2">
                <div>
                  <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-900">
                    Nearby Kabadi Listings
                  </h1>
                  <p className="text-xs sm:text-sm text-stone-600 mt-0.5">
                    Showing {filteredListings.length} recyclable scrap lots sorted by{' '}
                    {sortBy === 'distance' ? 'nearest distance first' : sortBy.replace('_', ' ')}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('rates')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-900 hover:underline"
                >
                  <TrendingUp className="w-4 h-4" />
                  <span>View Daily Market Rate Index (Iron Rs. 50/KG)</span>
                </button>
              </div>

              {filteredListings.length === 0 ? (
                <div className="bg-white border border-stone-200 rounded-2xl p-10 text-center space-y-3">
                  <p className="text-sm text-stone-600">
                    No scrap listings match your current distance or filter criteria.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setRadiusKm(100);
                      setSelectedCategory('All');
                      setMaxPricePerKg(1000);
                      setMinWeightKg(0);
                      setSearchQuery('');
                    }}
                    className="px-4 py-2 text-xs font-semibold bg-emerald-900 text-white rounded-xl"
                  >
                    Expand Search Radius to All Areas
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredListings.map((item) => (
                    <article
                      key={item.id}
                      onClick={() => {
                        setSelectedListing(item);
                        setActivePhotoIndex(0);
                        setDirectOfferPrice(String(item.askingPricePerKg));
                      }}
                      className="bg-white border border-stone-200/90 rounded-2xl overflow-hidden cursor-pointer hover:-translate-y-0.5 hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div>
                        {/* Lead with Imagery (4:3 aspect ratio) */}
                        <div className="aspect-4/3 w-full bg-stone-100 overflow-hidden relative">
                          <ResilientImage
                            src={item.photos[0]}
                            alt={item.title}
                            category={item.category}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        {/* Card Body — Zero-Pill Discipline: Unboxed metadata with typographic separators */}
                        <div className="p-5 space-y-2.5">
                          <div className="flex items-center justify-between text-xs text-stone-500">
                            <span>
                              {item.category} · {item.status}
                            </span>
                            <span className="font-mono tabular-nums font-medium text-emerald-900">
                              {item.distanceKm} KM away
                            </span>
                          </div>

                          <h2 className="font-display text-lg font-bold text-stone-900 leading-snug">
                            {item.title}
                          </h2>

                          {/* Weight, Price per KG, Total Estimated Price */}
                          <div className="pt-1 font-mono tabular-nums text-xs text-stone-700 space-y-1">
                            <div className="flex items-center justify-between">
                              <span>
                                <strong>{item.weightKg} KG</strong> ·{' '}
                                <strong>{formatRs(item.askingPricePerKg)}/KG</strong>
                              </span>
                              <span className="text-stone-500">
                                Market: {formatRs(item.marketPricePerKg)}/KG
                              </span>
                            </div>
                            <div className="text-sm font-bold text-stone-950">
                              Total: {formatRs(item.totalEstimatedPrice)}
                            </div>
                          </div>

                          {/* Seller Name, Rating & Location */}
                          <div className="pt-2.5 border-t border-stone-100 text-xs text-stone-600 space-y-1">
                            <div className="flex items-center justify-between">
                              <span>
                                Seller: <strong className="text-stone-900">{item.sellerName}</strong>
                              </span>
                              <span className="font-mono tabular-nums font-semibold text-amber-800">
                                ★ {item.sellerRating.toFixed(1)}
                              </span>
                            </div>
                            <div className="text-stone-500 truncate">
                              Location: {item.location.address}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Card Footer Action */}
                      <div
                        className="px-5 pb-4 pt-1 flex items-center gap-2"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          type="button"
                          onClick={() =>
                            handleStartChatOrNegotiation(item, item.askingPricePerKg)
                          }
                          className="flex-1 py-2.5 px-3 bg-emerald-900 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl transition-colors min-h-[40px]"
                        >
                          Negotiate / Buy
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setCallTarget({
                              name: item.sellerName,
                              phone: item.sellerPhone,
                              roleLabel: 'Seller',
                            })
                          }
                          className="py-2.5 px-3 bg-stone-100 hover:bg-stone-200 text-stone-900 text-xs font-semibold rounded-xl transition-colors min-h-[40px]"
                        >
                          Call
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              )}
            </section>

            {/* Interactive GPS Map Preview & Recent Listings Section (#7 & #13) */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start pt-4 border-t border-stone-200/80">
              <div className="lg:col-span-7 space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-xl font-bold text-stone-900">
                    GPS Map &amp; Nearby Pickup Pins
                  </h2>
                  <button
                    type="button"
                    onClick={() => setActiveTab('map')}
                    className="text-xs font-semibold text-emerald-900 hover:underline"
                  >
                    Open Full Map
                  </button>
                </div>
                <InteractiveMap
                  userLocation={currentUser.location}
                  onUpdateUserLocation={handleUpdateUserLocation}
                  liveLocationSharing={currentUser.liveLocationSharing}
                  onToggleLiveSharing={handleToggleLiveSharing}
                  listings={filteredListings}
                  radiusKm={radiusKm}
                  onChangeRadiusKm={setRadiusKm}
                  selectedListingId={selectedListing?.id}
                  onSelectListing={(item) => {
                    setSelectedListing(item);
                    setActivePhotoIndex(0);
                    setDirectOfferPrice(String(item.askingPricePerKg));
                  }}
                  navigationTarget={navigationTarget}
                  onClearNavigation={() => setNavigationTarget(null)}
                  compact
                />
              </div>

              {/* Recent Listings & Seller Quick Actions */}
              <div className="lg:col-span-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-xl font-bold text-stone-900">
                    Recent Listings
                  </h2>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingListing(null);
                      setIsSellerModalOpen(true);
                    }}
                    className="text-xs font-semibold text-emerald-900 hover:underline"
                  >
                    + Add Listing
                  </button>
                </div>

                <div className="bg-white border border-stone-200/90 rounded-2xl divide-y divide-stone-100">
                  {recentListings.map((rec) => (
                    <div
                      key={rec.id}
                      onClick={() => {
                        setSelectedListing(rec);
                        setActivePhotoIndex(0);
                        setDirectOfferPrice(String(rec.askingPricePerKg));
                      }}
                      className="p-4 flex items-center gap-3.5 hover:bg-stone-50 cursor-pointer transition-colors"
                    >
                      <div className="w-16 h-14 rounded-xl overflow-hidden bg-stone-100 shrink-0">
                        <ResilientImage
                          src={rec.photos[0]}
                          alt={rec.title}
                          category={rec.category}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-sm text-stone-900 truncate">
                          {rec.title}
                        </div>
                        <div className="text-xs text-stone-500 font-mono tabular-nums mt-0.5">
                          {rec.weightKg} KG · {formatRs(rec.askingPricePerKg)}/KG · Total{' '}
                          {formatRs(rec.totalEstimatedPrice)}
                        </div>
                        <div className="text-xs text-stone-500 truncate">
                          {rec.sellerName} · {rec.distanceKm} KM away ({rec.location.address})
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>
        )}

        {/* TAB 2: FULL INTERACTIVE GPS MAP */}
        {activeTab === 'map' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-900">
                  GPS Location &amp; Nearby Scrap Map
                </h1>
                <p className="text-sm text-stone-600 mt-1">
                  Detect your current GPS coordinates, adjust search radius (2 KM, 5 KM, 10 KM, 25
                  KM), and launch turn-by-turn directions to agreed pickup locations.
                </p>
              </div>
            </div>

            <InteractiveMap
              userLocation={currentUser.location}
              onUpdateUserLocation={handleUpdateUserLocation}
              liveLocationSharing={currentUser.liveLocationSharing}
              onToggleLiveSharing={handleToggleLiveSharing}
              listings={filteredListings}
              radiusKm={radiusKm}
              onChangeRadiusKm={setRadiusKm}
              selectedListingId={selectedListing?.id}
              onSelectListing={(item) => {
                setSelectedListing(item);
                setActivePhotoIndex(0);
                setDirectOfferPrice(String(item.askingPricePerKg));
              }}
              navigationTarget={navigationTarget}
              onClearNavigation={() => setNavigationTarget(null)}
            />
          </div>
        )}

        {/* TAB 3: AUTOMATIC MARKET PRICES (#6) */}
        {activeTab === 'rates' && (
          <MarketPriceView
            rates={marketRates}
            currentUserRole={currentUser.role}
            onUpdateMarketRate={handleUpdateMarketRate}
          />
        )}

        {/* TAB 4: REAL-TIME CHAT & PRICE NEGOTIATION (#10) */}
        {activeTab === 'messages' && (
          <ChatAndNegotiation
            threads={threads}
            messages={messages}
            currentUser={currentUser}
            selectedThreadId={selectedThreadId}
            onSelectThread={setSelectedThreadId}
            onSendMessage={handleSendMessage}
            onConfirmFinalPrice={handleConfirmFinalPrice}
            onOpenCallModal={(name, phone, roleLabel) =>
              setCallTarget({ name, phone, roleLabel })
            }
            onViewProfile={(uid) => setInspectingUserId(uid)}
          />
        )}

        {/* TAB 5: TRANSACTION SYSTEM (#12) */}
        {activeTab === 'transactions' && (
          <TransactionsView
            transactions={transactions}
            currentUser={currentUser}
            onUpdateStatus={handleUpdateTransactionStatus}
            onCancelTransaction={handleCancelTransaction}
            onSubmitReview={handleSubmitReview}
            onNavigateToPickup={(title, destination) => {
              setNavigationTarget({ title, destination });
              setActiveTab('map');
            }}
            onViewProfile={(uid) => setInspectingUserId(uid)}
          />
        )}
      </main>

      {/* LISTING DETAIL & BUYER/SELLER ACTION MODAL (#4, #5, #8, #12) */}
      {selectedListing && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white border border-stone-200 rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-xl my-8 max-h-[92vh] overflow-y-auto space-y-6">
            <div className="flex items-start justify-between gap-4 border-b border-stone-200 pb-4">
              <div>
                <div className="text-xs text-stone-500">
                  {selectedListing.category} · Status: {selectedListing.status} ·{' '}
                  {calculateDistanceKm(currentUser.location, selectedListing.location)} KM from
                  your location
                </div>
                <h2 className="font-display text-2xl font-bold text-stone-900 mt-0.5">
                  {selectedListing.title}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setSelectedListing(null)}
                className="w-10 h-10 rounded-xl bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Left Multi-Photo Viewer */}
              <div className="md:col-span-6 space-y-3">
                <div className="aspect-4/3 rounded-2xl overflow-hidden bg-stone-100 border border-stone-200">
                  <ResilientImage
                    src={
                      selectedListing.photos[activePhotoIndex] || selectedListing.photos[0]
                    }
                    alt={selectedListing.title}
                    category={selectedListing.category}
                    className="w-full h-full object-cover"
                  />
                </div>
                {selectedListing.photos.length > 1 && (
                  <div className="flex items-center gap-2">
                    {selectedListing.photos.map((ph, idx) => (
                      <button
                        key={`${ph.slice(-12)}-${idx}`}
                        type="button"
                        onClick={() => setActivePhotoIndex(idx)}
                        className={`w-16 h-12 rounded-lg overflow-hidden border-2 ${
                          activePhotoIndex === idx
                            ? 'border-emerald-900'
                            : 'border-transparent opacity-70'
                        }`}
                      >
                        <ResilientImage
                          src={ph}
                          alt={`Thumbnail ${idx + 1}`}
                          category={selectedListing.category}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                )}

                <p className="text-xs text-stone-600 leading-relaxed pt-1">
                  {selectedListing.description}
                </p>
              </div>

              {/* Right Pricing, Seller Info, Negotiation & Pickup Controls */}
              <div className="md:col-span-6 space-y-4">
                <div className="p-4 bg-stone-50 border border-stone-200/90 rounded-2xl space-y-2 font-mono tabular-nums text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-sans text-stone-600">Quantity / Weight:</span>
                    <span className="font-bold text-stone-900 text-sm">
                      {selectedListing.weightKg} KG
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-sans text-stone-600">Current Market Price:</span>
                    <span className="text-stone-800">
                      {formatRs(selectedListing.marketPricePerKg)}/KG
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-sans text-stone-600">Seller Asking Price:</span>
                    <span className="font-bold text-emerald-900 text-sm">
                      {formatRs(selectedListing.askingPricePerKg)}/KG
                    </span>
                  </div>
                  <div className="pt-2 border-t border-stone-200 flex items-center justify-between text-sm font-bold text-stone-950">
                    <span className="font-sans">Total Estimated Price:</span>
                    <span>{formatRs(selectedListing.totalEstimatedPrice)}</span>
                  </div>
                </div>

                {/* Seller Profile & Pickup Location */}
                <div className="p-4 border border-stone-200 rounded-2xl space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-stone-500">Seller: </span>
                      <button
                        type="button"
                        onClick={() => {
                          const sid = selectedListing.sellerId;
                          setSelectedListing(null);
                          setInspectingUserId(sid);
                        }}
                        className="font-bold text-stone-900 underline hover:text-emerald-800"
                      >
                        {selectedListing.sellerName}
                      </button>
                      <span className="font-mono text-amber-800 font-semibold ml-1.5">
                        ★ {selectedListing.sellerRating.toFixed(1)}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const sid = selectedListing.sellerId;
                        setSelectedListing(null);
                        setInspectingUserId(sid);
                      }}
                      className="text-emerald-800 font-semibold hover:underline"
                    >
                      View Seller Profile
                    </button>
                  </div>

                  <div className="flex items-center justify-between text-stone-600 pt-1">
                    <span>Pickup: {selectedListing.location.address}</span>
                    <button
                      type="button"
                      onClick={() => {
                        setNavigationTarget({
                          title: selectedListing.title,
                          destination: selectedListing.location,
                        });
                        setSelectedListing(null);
                        setActiveTab('map');
                      }}
                      className="inline-flex items-center gap-1 text-emerald-800 font-semibold hover:underline"
                    >
                      <Navigation className="w-3 h-3" />
                      <span>Map &amp; Route</span>
                    </button>
                  </div>
                </div>

                {/* Negotiate Price & Arrange Pickup Schedule */}
                <div className="p-4 bg-emerald-50/60 border border-emerald-200 rounded-2xl space-y-3">
                  <div className="text-xs font-semibold text-emerald-950">
                    Negotiate Rate &amp; Schedule Pickup
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] text-stone-600 mb-1">
                        Offer Price (Rs./KG)
                      </label>
                      <input
                        type="number"
                        min={1}
                        value={directOfferPrice}
                        onChange={(e) => setDirectOfferPrice(e.target.value)}
                        className="w-full px-3 py-2 text-xs font-mono bg-white border border-stone-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-stone-600 mb-1">
                        Preferred Pickup Time
                      </label>
                      <input
                        type="text"
                        value={pickupScheduleInput}
                        onChange={(e) => setPickupScheduleInput(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() =>
                        handleStartChatOrNegotiation(
                          selectedListing,
                          Number(directOfferPrice) || selectedListing.askingPricePerKg
                        )
                      }
                      className="flex-1 py-2.5 px-3 bg-emerald-900 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl inline-flex items-center justify-center gap-1.5 min-h-[42px]"
                    >
                      <Handshake className="w-4 h-4" />
                      <span>Send Offer in Chat</span>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setCallTarget({
                          name: selectedListing.sellerName,
                          phone: selectedListing.sellerPhone,
                          roleLabel: 'Seller',
                        })
                      }
                      className="py-2.5 px-3.5 bg-white border border-stone-300 hover:border-stone-900 text-stone-900 text-xs font-semibold rounded-xl inline-flex items-center gap-1.5 min-h-[42px]"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-emerald-800" />
                      <span>Call Seller</span>
                    </button>
                  </div>
                </div>

                {/* Seller Listing Management Controls (#5) */}
                {(currentUser.id === selectedListing.sellerId ||
                  currentUser.role === UserRole.SELLER ||
                  currentUser.role === UserRole.ADMIN) && (
                  <div className="pt-3 border-t border-stone-200 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-[11px] text-stone-500">Seller Controls:</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const target = selectedListing;
                          setSelectedListing(null);
                          setEditingListing(target);
                          setIsSellerModalOpen(true);
                        }}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium bg-stone-100 hover:bg-stone-200 text-stone-900 rounded-lg"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Edit</span>
                      </button>

                      {selectedListing.status !== 'Sold' && (
                        <button
                          type="button"
                          onClick={() => handleMarkAsSold(selectedListing)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium bg-emerald-100 hover:bg-emerald-200 text-emerald-950 rounded-lg"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Mark Sold</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleDeleteListing(selectedListing.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium bg-red-50 hover:bg-red-100 text-red-800 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SELLER ADD / EDIT LISTING MODAL (#5) */}
      <SellerListingModal
        isOpen={isSellerModalOpen}
        onClose={() => setIsSellerModalOpen(false)}
        currentUser={currentUser}
        marketRates={marketRates}
        editingListing={editingListing}
        onSaveListing={handleSaveListing}
      />

      {/* USER PROFILE MODAL (#11) */}
      <UserProfileModal
        profileUser={inspectedUser}
        reviews={reviews}
        isOwnProfile={inspectedUser?.id === currentUser.id}
        onClose={() => setInspectingUserId(null)}
        onSaveProfile={(updated) => {
          setUsers((prev) =>
            prev.map((u) => (u.id === updated.id ? updated : u))
          );
        }}
      />

      {/* DOWNLOAD & PWA INSTALL MODAL */}
      <PWAInstallModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        onExportBackupJson={() => {
          const payload = {
            exportedAt: new Date().toISOString(),
            app: 'Hamro Kabadi',
            marketRates,
            listings,
            transactions,
          };
          const blob = new Blob([JSON.stringify(payload, null, 2)], {
            type: 'application/json',
          });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'hamro-kabadi-marketplace-data.json';
          a.click();
          URL.revokeObjectURL(url);
        }}
      />

      {/* VOICE CALL MODAL (#4, #5, #10) */}
      {callTarget && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white border border-stone-200 rounded-3xl max-w-sm w-full p-6 text-center space-y-4 shadow-xl">
            <div className="w-14 h-14 rounded-2xl bg-emerald-900 text-white flex items-center justify-center mx-auto">
              <PhoneCall className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs text-stone-500">
                Direct {callTarget.roleLabel} Contact
              </div>
              <h3 className="font-display text-xl font-bold text-stone-900 mt-0.5">
                {callTarget.name}
              </h3>
              <p className="font-mono text-base font-semibold text-emerald-900 mt-1">
                +977 {callTarget.phone}
              </p>
            </div>
            <div className="flex items-center gap-2 pt-2">
              <a
                href={`tel:+977${callTarget.phone}`}
                className="flex-1 py-2.5 bg-emerald-900 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl min-h-[42px] flex items-center justify-center"
              >
                Dial Number
              </a>
              <button
                type="button"
                onClick={() => setCallTarget(null)}
                className="flex-1 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-xl min-h-[42px]"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MOBILE BOTTOM NAVIGATION BAR (Thumb-Zone Ergonomics, <= 15% Viewport Height) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 grid grid-cols-5 items-center h-15 px-2"
      >
        {[
          { id: 'home', label: 'Nearby', icon: Compass },
          { id: 'map', label: 'GPS Map', icon: MapPin },
          { id: 'rates', label: 'Rates', icon: TrendingUp },
          { id: 'messages', label: 'Chat', icon: MessageSquare },
          { id: 'transactions', label: 'Deals', icon: Receipt },
        ].map((tab) => {
          const IconComponent = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as MainTab)}
              className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
                active ? 'text-emerald-900 font-semibold' : 'text-stone-500'
              }`}
            >
              <IconComponent className="w-5 h-5" />
              <span className="text-[10px] mt-0.5 whitespace-nowrap">{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
