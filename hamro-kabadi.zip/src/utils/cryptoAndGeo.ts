import { GeoPoint, MaterialCategory } from '../types';

/**
 * Compute salted SHA-256 hash using Web Crypto API (with synchronous deterministic fallback)
 */
export async function hashPassword(password: string, salt: string): Promise<string> {
  const input = `${salt}:${password}:hamro_kabadi_v1`;
  if (typeof window !== 'undefined' && window.crypto && window.crypto.subtle) {
    const encoder = new TextEncoder();
    const data = encoder.encode(input);
    const digest = await window.crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  return simpleDeterministicHash(input);
}

export function simpleDeterministicHash(input: string): string {
  let h1 = 0xdeadbeef ^ input.length;
  let h2 = 0x41c6ce57 ^ input.length;
  for (let i = 0, ch; i < input.length; i++) {
    ch = input.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (h2 >>> 0).toString(16).padStart(8, '0') + (h1 >>> 0).toString(16).padStart(8, '0');
}

export function generateSalt(): string {
  if (typeof window !== 'undefined' && window.crypto) {
    const bytes = new Uint8Array(8);
    window.crypto.getRandomValues(bytes);
    return Array.from(bytes)
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  return Math.random().toString(36).substring(2, 10);
}

export function generateSecureOTP(): string {
  if (typeof window !== 'undefined' && window.crypto) {
    const array = new Uint32Array(1);
    window.crypto.getRandomValues(array);
    const code = (array[0] % 900000) + 100000;
    return String(code);
  }
  return String(Math.floor(100000 + Math.random() * 900000));
}

export function generateUniqueUserId(prefix = 'HK'): string {
  const num = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${num}`;
}

/**
 * Haversine formula to compute exact distance in kilometers between two GPS coordinates
 */
export function calculateDistanceKm(a: GeoPoint, b: GeoPoint): number {
  const R = 6371; // Earth radius in KM
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);

  const sinDLat = Math.sin(dLat / 2);
  const sinDLng = Math.sin(dLng / 2);
  const h =
    sinDLat * sinDLat +
    Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
  const c = 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
  const dist = R * c;
  return Math.round(dist * 10) / 10;
}

function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

export function formatRs(amount: number): string {
  return `Rs. ${amount.toLocaleString('en-IN')}`;
}

export const KATHMANDU_LOCATIONS: GeoPoint[] = [
  { lat: 27.6915, lng: 85.342, address: 'New Baneshwor, Kathmandu' },
  { lat: 27.7058, lng: 85.3322, address: 'Putalisadak, Kathmandu' },
  { lat: 27.671, lng: 85.324, address: 'Jawalakhel, Lalitpur' },
  { lat: 27.699, lng: 85.2985, address: 'Kalimati, Kathmandu' },
  { lat: 27.7362, lng: 85.3304, address: 'Maharajgunj, Kathmandu' },
  { lat: 27.6782, lng: 85.3495, address: 'Koteshwor, Kathmandu' },
  { lat: 27.7215, lng: 85.362, address: 'Boudha, Kathmandu' },
  { lat: 27.734, lng: 85.3015, address: 'Balaju Industrial Area, Kathmandu' },
  { lat: 27.6722, lng: 85.4278, address: 'Suryabinayak, Bhaktapur' },
];

export function getCategoryFallbackGradient(category: MaterialCategory): string {
  switch (category) {
    case MaterialCategory.IRON:
    case MaterialCategory.STEEL:
      return 'from-zinc-800 to-stone-700';
    case MaterialCategory.COPPER:
    case MaterialCategory.BRASS:
      return 'from-amber-800 to-orange-900';
    case MaterialCategory.ALUMINIUM:
    case MaterialCategory.EWASTE:
      return 'from-slate-700 to-emerald-900';
    case MaterialCategory.PAPER:
    case MaterialCategory.CARDBOARD:
      return 'from-stone-700 to-amber-950';
    case MaterialCategory.PLASTIC:
    case MaterialCategory.GLASS:
    default:
      return 'from-emerald-800 to-teal-950';
  }
}
