export enum UserRole {
  BUYER = 'Buyer',
  SELLER = 'Seller',
  ADMIN = 'Admin',
}

export enum MaterialCategory {
  IRON = 'Iron',
  STEEL = 'Steel',
  ALUMINIUM = 'Aluminium',
  COPPER = 'Copper',
  BRASS = 'Brass',
  PLASTIC = 'Plastic',
  PAPER = 'Paper',
  CARDBOARD = 'Cardboard',
  GLASS = 'Glass',
  EWASTE = 'Electronic waste',
  OTHER = 'Other',
}

export enum TransactionStatus {
  PENDING = 'Pending',
  NEGOTIATING = 'Negotiating',
  CONFIRMED = 'Confirmed',
  PICKED_UP = 'Picked Up',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled',
}

export interface GeoPoint {
  lat: number;
  lng: number;
  address: string;
}

export interface UserReview {
  id: string;
  reviewerId: string;
  reviewerName: string;
  reviewerRole: UserRole;
  targetUserId: string;
  transactionId: string;
  rating: number;
  comment: string;
  createdAt: string;
}

export interface UserAccount {
  id: string; // Unique system User ID e.g. HK-1001
  userId: string; // Login User ID handle e.g. ram_kabadi
  fullName: string;
  phone: string;
  email?: string;
  passwordHash: string;
  salt: string;
  role: UserRole;
  profilePhoto: string;
  location: GeoPoint;
  locationPermissionGranted: boolean;
  liveLocationSharing: boolean;
  phoneVerified: boolean;
  verifiedBadge: boolean;
  rating: number;
  reviewCount: number;
  completedTransactions: number;
  createdAt: string;
}

export interface PriceHistoryEntry {
  date: string;
  marketPricePerKg: number;
  suggestedBuyingPrice: number;
  suggestedSellingPrice: number;
  updatedBy: string;
}

export interface MaterialPriceRate {
  category: MaterialCategory;
  nepaliName: string;
  marketPricePerKg: number;
  suggestedBuyingPrice: number;
  suggestedSellingPrice: number;
  updatedAt: string;
  unit: 'KG';
  description: string;
  history: PriceHistoryEntry[];
}

export interface ScrapListing {
  id: string;
  title: string;
  category: MaterialCategory;
  weightKg: number;
  marketPricePerKg: number;
  askingPricePerKg: number;
  totalEstimatedPrice: number;
  photos: string[];
  description: string;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  sellerRating: number;
  sellerVerified: boolean;
  location: GeoPoint;
  status: 'Available' | 'Negotiating' | 'Sold';
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  threadId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  text: string;
  photoUrl?: string;
  offeredPricePerKg?: number;
  offerStatus?: 'pending' | 'accepted' | 'countered';
  sharedLocation?: GeoPoint;
  isFinalConfirmation?: boolean;
  createdAt: string;
}

export interface ChatThread {
  id: string;
  listingId: string;
  listingTitle: string;
  listingCategory: MaterialCategory;
  listingWeightKg: number;
  listingAskingPricePerKg: number;
  buyerId: string;
  buyerName: string;
  buyerPhone: string;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  currentAgreedPricePerKg?: number;
  pickupLocation: GeoPoint;
  updatedAt: string;
}

export interface ScrapTransaction {
  id: string;
  listingId: string;
  listingTitle: string;
  category: MaterialCategory;
  weightKg: number;
  agreedPricePerKg: number;
  totalAgreedAmount: number;
  buyerId: string;
  buyerName: string;
  buyerPhone: string;
  sellerId: string;
  sellerName: string;
  sellerPhone: string;
  pickupLocation: GeoPoint;
  scheduledPickupTime?: string;
  status: TransactionStatus;
  createdAt: string;
  updatedAt: string;
  cancelledBy?: string;
  cancelReason?: string;
  buyerReviewed?: boolean;
  sellerReviewed?: boolean;
}

export interface AppNotification {
  id: string;
  userId: string;
  title: string;
  body: string;
  type: 'offer' | 'transaction' | 'price_update' | 'system';
  read: boolean;
  createdAt: string;
  relatedId?: string;
}
