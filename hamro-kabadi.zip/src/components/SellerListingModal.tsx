import React, { useEffect, useState } from 'react';
import { LocateFixed, Plus, Trash2, Upload, X } from 'lucide-react';
import {
  GeoPoint,
  MaterialCategory,
  MaterialPriceRate,
  ScrapListing,
  UserAccount,
} from '../types';
import { CATEGORY_IMAGES } from '../data/initialData';
import { formatRs, KATHMANDU_LOCATIONS } from '../utils/cryptoAndGeo';
import { ResilientImage } from './ResilientImage';

interface SellerListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount;
  marketRates: MaterialPriceRate[];
  editingListing?: ScrapListing | null;
  onSaveListing: (listing: ScrapListing, isEdit: boolean) => void;
}

export const SellerListingModal: React.FC<SellerListingModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  marketRates,
  editingListing,
  onSaveListing,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<MaterialCategory>(MaterialCategory.IRON);
  const [weightKg, setWeightKg] = useState<number>(25);
  const [askingPricePerKg, setAskingPricePerKg] = useState<number>(40);
  const [description, setDescription] = useState('');
  const [photos, setPhotos] = useState<string[]>([CATEGORY_IMAGES[MaterialCategory.IRON]]);
  const [pickupLocation, setPickupLocation] = useState<GeoPoint>(currentUser.location);

  const activeRate =
    marketRates.find((r) => r.category === category) || marketRates[0];

  useEffect(() => {
    if (editingListing) {
      setTitle(editingListing.title);
      setCategory(editingListing.category);
      setWeightKg(editingListing.weightKg);
      setAskingPricePerKg(editingListing.askingPricePerKg);
      setDescription(editingListing.description);
      setPhotos(editingListing.photos);
      setPickupLocation(editingListing.location);
    } else {
      const defaultRate =
        marketRates.find((r) => r.category === MaterialCategory.IRON) || marketRates[0];
      setTitle('Iron Scrap');
      setCategory(MaterialCategory.IRON);
      setWeightKg(25);
      setAskingPricePerKg(defaultRate.suggestedSellingPrice);
      setDescription(
        'Clean, sorted recyclable scrap material ready for doorstep weighing and pickup.'
      );
      setPhotos([CATEGORY_IMAGES[MaterialCategory.IRON]]);
      setPickupLocation(currentUser.location);
    }
  }, [editingListing, isOpen, currentUser.location, marketRates]);

  if (!isOpen) return null;

  const handleCategoryChange = (newCat: MaterialCategory) => {
    setCategory(newCat);
    const rate = marketRates.find((r) => r.category === newCat);
    if (rate) {
      setAskingPricePerKg(rate.suggestedSellingPrice);
    }
    if (!editingListing) {
      setTitle(`${newCat} Scrap`);
      setPhotos([CATEGORY_IMAGES[newCat]]);
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setPhotos((prev) => [...prev, reader.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDetectCurrentGps = () => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setPickupLocation({
            lat: Number(pos.coords.latitude.toFixed(4)),
            lng: Number(pos.coords.longitude.toFixed(4)),
            address: `GPS Pickup (${pos.coords.latitude.toFixed(3)}°N, ${pos.coords.longitude.toFixed(3)}°E)`,
          });
        },
        () => {
          setPickupLocation(currentUser.location);
        }
      );
    }
  };

  const totalEstimatedPrice = Math.round(weightKg * askingPricePerKg);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newListing: ScrapListing = {
      id: editingListing ? editingListing.id : `LST-${Math.floor(2010 + Math.random() * 7900)}`,
      title: title.trim() || `${category} Scrap`,
      category,
      weightKg: Math.max(1, Number(weightKg)),
      marketPricePerKg: activeRate.marketPricePerKg,
      askingPricePerKg: Math.max(1, Number(askingPricePerKg)),
      totalEstimatedPrice,
      photos: photos.length > 0 ? photos : [CATEGORY_IMAGES[category]],
      description: description.trim(),
      sellerId: currentUser.id,
      sellerName: currentUser.fullName.split(' ')[0],
      sellerPhone: currentUser.phone,
      sellerRating: currentUser.rating,
      sellerVerified: currentUser.verifiedBadge,
      location: pickupLocation,
      status: editingListing ? editingListing.status : 'Available',
      createdAt: editingListing ? editingListing.createdAt : new Date().toISOString(),
    };

    onSaveListing(newListing, Boolean(editingListing));
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white border border-stone-200 rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-xl my-8 max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-stone-200 pb-4 mb-5">
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-stone-900">
              {editingListing ? 'Edit Scrap Listing' : 'Add New Scrap Listing'}
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Automatic market price benchmark is shown below for your chosen material.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-10 h-10 rounded-xl bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Material Category & Listing Title */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1.5">
                Select Material Category *
              </label>
              <select
                value={category}
                onChange={(e) => handleCategoryChange(e.target.value as MaterialCategory)}
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:outline-none focus:border-emerald-900 min-h-[44px]"
              >
                {Object.values(MaterialCategory).map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1.5">
                Listing Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Iron Scrap"
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:outline-none focus:border-emerald-900 min-h-[44px]"
              />
            </div>
          </div>

          {/* Automatic Market Price Benchmark Banner */}
          <div className="p-4 bg-stone-50 border border-stone-200/90 rounded-2xl flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-0.5">
              <div className="text-xs font-semibold text-stone-900">
                Automatic Market Benchmark · {activeRate.category} ({activeRate.nepaliName})
              </div>
              <div className="text-xs text-stone-600 font-mono tabular-nums">
                Market price: <strong>{formatRs(activeRate.marketPricePerKg)}/KG</strong> ·
                Suggested seller price:{' '}
                <strong className="text-emerald-900">
                  {formatRs(activeRate.suggestedSellingPrice)}/KG
                </strong>{' '}
                · Suggested buyer price: {formatRs(activeRate.suggestedBuyingPrice)}/KG
              </div>
            </div>
            <button
              type="button"
              onClick={() => setAskingPricePerKg(activeRate.suggestedSellingPrice)}
              className="px-3 py-1.5 text-xs font-semibold bg-white border border-stone-300 hover:border-stone-900 rounded-lg text-stone-900 transition-colors"
            >
              Use Suggested ({formatRs(activeRate.suggestedSellingPrice)}/KG)
            </button>
          </div>

          {/* Weight (KG) & Final Selling Price per KG */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1.5">
                Weight in KG *
              </label>
              <input
                type="number"
                required
                min={1}
                step="0.5"
                value={weightKg}
                onChange={(e) => setWeightKg(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:outline-none focus:border-emerald-900 font-mono tabular-nums min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1.5">
                Your Selling Price (Rs./KG) *
              </label>
              <input
                type="number"
                required
                min={1}
                value={askingPricePerKg}
                onChange={(e) => setAskingPricePerKg(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:outline-none focus:border-emerald-900 font-mono tabular-nums min-h-[44px]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1.5">
                Total Estimated Price
              </label>
              <div className="w-full px-3.5 py-2.5 text-sm bg-emerald-950 text-white rounded-xl font-mono tabular-nums font-bold flex items-center min-h-[44px]">
                {formatRs(totalEstimatedPrice)}
              </div>
            </div>
          </div>

          {/* Multiple Photos Upload */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-medium text-stone-700">
                Item Photos (Upload Multiple)
              </label>
              <label
                htmlFor="seller-multi-photos"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-900 rounded-lg cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Add Photos</span>
              </label>
              <input
                id="seller-multi-photos"
                type="file"
                accept="image/*"
                multiple
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </div>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
              {photos.map((photo, index) => (
                <div
                  key={`${photo.slice(-15)}-${index}`}
                  className="relative h-24 rounded-xl overflow-hidden border border-stone-200 group"
                >
                  <ResilientImage
                    src={photo}
                    alt={`${title} photo ${index + 1}`}
                    category={category}
                    className="w-full h-full object-cover"
                  />
                  {photos.length > 1 && (
                    <button
                      type="button"
                      onClick={() =>
                        setPhotos((prev) => prev.filter((_, idx) => idx !== index))
                      }
                      className="absolute top-1.5 right-1.5 w-6 h-6 rounded-md bg-black/70 text-white flex items-center justify-center opacity-90 hover:bg-red-700"
                      title="Remove photo"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
              <button
                type="button"
                onClick={() => {
                  const presetValues = Object.values(CATEGORY_IMAGES);
                  const nextImg =
                    presetValues[photos.length % presetValues.length];
                  setPhotos((prev) => [...prev, nextImg]);
                }}
                className="h-24 rounded-xl border border-dashed border-stone-300 hover:border-stone-900 flex flex-col items-center justify-center text-xs text-stone-500 hover:text-stone-900 transition-colors"
              >
                <Plus className="w-4 h-4 mb-1" />
                <span>Add Sample Photo</span>
              </button>
            </div>
          </div>

          {/* Pickup Location */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-medium text-stone-700">
                Pickup Location *
              </label>
              <button
                type="button"
                onClick={handleDetectCurrentGps}
                className="inline-flex items-center gap-1 text-xs font-medium text-emerald-800 hover:underline"
              >
                <LocateFixed className="w-3.5 h-3.5" />
                <span>Use Current GPS</span>
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <select
                value={pickupLocation.address}
                onChange={(e) => {
                  const found = KATHMANDU_LOCATIONS.find(
                    (l) => l.address === e.target.value
                  );
                  if (found) setPickupLocation(found);
                }}
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl"
              >
                {KATHMANDU_LOCATIONS.map((loc) => (
                  <option key={loc.address} value={loc.address}>
                    {loc.address}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={pickupLocation.address}
                onChange={(e) =>
                  setPickupLocation({ ...pickupLocation, address: e.target.value })
                }
                placeholder="Street landmark or pickup address"
                className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-xs font-medium text-stone-700 mb-1.5">
              Material Condition & Pickup Notes
            </label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe scrap condition, floor access, or preferred pickup hours..."
              className="w-full px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:outline-none focus:border-emerald-900"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-xl min-h-[44px]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-semibold text-white bg-emerald-900 hover:bg-emerald-800 rounded-xl min-h-[44px]"
            >
              {editingListing ? 'Save Changes' : 'Publish Scrap Listing'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
