import React, { useState } from 'react';
import {
  Check,
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  Smartphone,
  X,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExportBackupJson: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({
  isOpen,
  onClose,
  onExportBackupJson,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const mobileAppUrl =
    'https://ais-pre-t4bivdxmhzti3ltrzzr53b-973340019492.asia-southeast1.run.app';

  const handleCopyLink = () => {
    navigator.clipboard.writeText(mobileAppUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white border border-stone-200 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-xl my-8">
        <div className="flex items-start justify-between gap-4 border-b border-stone-200 pb-4">
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-bold text-stone-900">
              Download to Mobile Phone
            </h2>
            <p className="text-xs text-stone-500 mt-1">
              Hamro Kabadi is configured as a Progressive Web App (PWA) for Android and iPhone.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-700 shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Direct Mobile Link Box */}
          <div className="p-4 rounded-2xl bg-emerald-950 text-white space-y-3">
            <div className="text-xs font-semibold text-emerald-200">
              Step 1: Open this link on your mobile phone browser
            </div>
            <div className="flex items-center gap-2 bg-black/30 p-2.5 rounded-xl border border-emerald-800">
              <span className="text-xs font-mono truncate flex-1 select-all">
                {mobileAppUrl}
              </span>
              <button
                type="button"
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold bg-white text-emerald-950 rounded-lg hover:bg-emerald-50 shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Link'}</span>
              </button>
            </div>
            {isInstallable && !isInstalled && (
              <button
                type="button"
                onClick={install}
                className="w-full py-2.5 px-4 bg-white text-emerald-950 text-xs font-bold rounded-xl flex items-center justify-center gap-2 min-h-[42px]"
              >
                <Download className="w-4 h-4" />
                <span>Install App Directly Now</span>
              </button>
            )}
          </div>

          {/* Step 2: Android vs iPhone Instructions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-800 shrink-0" />
                <h3 className="text-xs font-bold text-stone-900">On Android (Chrome)</h3>
              </div>
              <ol className="list-decimal list-inside text-xs text-stone-600 space-y-1.5 leading-relaxed">
                <li>Open the link above in Chrome on your Android phone.</li>
                <li>
                  Tap the <strong>three dots (⋮)</strong> menu in the top-right corner.
                </li>
                <li>
                  Tap <strong>Install app</strong> or <strong>Add to Home screen</strong>.
                </li>
              </ol>
            </div>

            <div className="p-4 rounded-2xl bg-stone-50 border border-stone-200 space-y-2">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-emerald-800 shrink-0" />
                <h3 className="text-xs font-bold text-stone-900">On iPhone / iPad (Safari)</h3>
              </div>
              <ol className="list-decimal list-inside text-xs text-stone-600 space-y-1.5 leading-relaxed">
                <li>Open the link above in Safari on your iPhone.</li>
                <li>
                  Tap the <strong>Share</strong> icon (square with arrow pointing up) at the
                  bottom.
                </li>
                <li>
                  Scroll down and tap <strong>Add to Home Screen</strong>.
                </li>
              </ol>
            </div>
          </div>

          {isInstalled && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-2 text-xs text-emerald-900 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>Hamro Kabadi is currently installed on this device!</span>
            </div>
          )}

          {/* Optional Data Backup */}
          <div className="pt-2 border-t border-stone-200 flex items-center justify-between gap-3">
            <a
              href={mobileAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-900 hover:underline"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open Full-Screen App URL</span>
            </a>

            <button
              type="button"
              onClick={onExportBackupJson}
              className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold rounded-lg"
            >
              Export Data (JSON)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
