import React, { useState } from 'react';
import {
  Compass,
  LocateFixed,
  MapPin,
  Navigation,
  Plus,
  Minus,
  ShieldCheck,
  Truck,
} from 'lucide-react';
import { GeoPoint, ScrapListing } from '../types';
import {
  calculateDistanceKm,
  formatRs,
  KATHMANDU_LOCATIONS,
} from '../utils/cryptoAndGeo';

interface InteractiveMapProps {
  userLocation: GeoPoint;
  onUpdateUserLocation: (loc: GeoPoint, permissionGranted: boolean) => void;
  liveLocationSharing: boolean;
  onToggleLiveSharing: (enabled: boolean) => void;
  listings: ScrapListing[];
  radiusKm: number;
  onChangeRadiusKm: (r: number) => void;
  selectedListingId?: string | null;
  onSelectListing: (listing: ScrapListing) => void;
  navigationTarget?: {
    title: string;
    destination: GeoPoint;
  } | null;
  onClearNavigation?: () => void;
  pickerMode?: boolean;
  onPickLocation?: (loc: GeoPoint) => void;
  compact?: boolean;
}

const CENTER_LAT = 27.702;
const CENTER_LNG = 85.338;
const LAT_SPAN = 0.085;
const LNG_SPAN = 0.115;

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  userLocation,
  onUpdateUserLocation,
  liveLocationSharing,
  onToggleLiveSharing,
  listings,
  radiusKm,
  onChangeRadiusKm,
  selectedListingId,
  onSelectListing,
  navigationTarget,
  onClearNavigation,
  pickerMode = false,
  onPickLocation,
  compact = false,
}) => {
  const [zoom, setZoom] = useState<number>(1);
  const [gpsStatus, setGpsStatus] = useState<string>('');

  const projectPoint = (pt: GeoPoint) => {
    const normX = ((pt.lng - (CENTER_LNG - LNG_SPAN / (2 * zoom))) / (LNG_SPAN / zoom)) * 100;
    const normY = ((CENTER_LAT + LAT_SPAN / (2 * zoom) - pt.lat) / (LAT_SPAN / zoom)) * 100;
    return {
      x: Math.max(6, Math.min(94, normX)),
      y: Math.max(8, Math.min(92, normY)),
    };
  };

  const userPos = projectPoint(userLocation);
  const navDestPos = navigationTarget ? projectPoint(navigationTarget.destination) : null;
  const navDistanceKm = navigationTarget
    ? calculateDistanceKm(userLocation, navigationTarget.destination)
    : 0;
  const estimatedDriveMins = Math.max(4, Math.round(navDistanceKm * 3.5));

  const handleDetectGps = () => {
    setGpsStatus('Detecting GPS coordinates...');
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const detected: GeoPoint = {
            lat: Number(pos.coords.latitude.toFixed(4)),
            lng: Number(pos.coords.longitude.toFixed(4)),
            address: `GPS Location (${pos.coords.latitude.toFixed(3)}°N, ${pos.coords.longitude.toFixed(3)}°E)`,
          };
          onUpdateUserLocation(detected, true);
          setGpsStatus('GPS location updated');
          setTimeout(() => setGpsStatus(''), 3000);
        },
        () => {
          const fallback = KATHMANDU_LOCATIONS[0];
          onUpdateUserLocation(fallback, true);
          setGpsStatus('Set to New Baneshwor, Kathmandu');
          setTimeout(() => setGpsStatus(''), 3000);
        },
        { enableHighAccuracy: true, timeout: 5000 }
      );
    } else {
      onUpdateUserLocation(KATHMANDU_LOCATIONS[0], true);
      setGpsStatus('Set to New Baneshwor, Kathmandu');
      setTimeout(() => setGpsStatus(''), 3000);
    }
  };

  const handleMapSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!pickerMode || !onPickLocation) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = (e.clientX - rect.left) / rect.width;
    const clickY = (e.clientY - rect.top) / rect.height;
    const lng = CENTER_LNG - LNG_SPAN / (2 * zoom) + clickX * (LNG_SPAN / zoom);
    const lat = CENTER_LAT + LAT_SPAN / (2 * zoom) - clickY * (LAT_SPAN / zoom);

    let closestArea = KATHMANDU_LOCATIONS[0];
    let minD = 999;
    for (const loc of KATHMANDU_LOCATIONS) {
      const d = calculateDistanceKm({ lat, lng, address: '' }, loc);
      if (d < minD) {
        minD = d;
        closestArea = loc;
      }
    }
    onPickLocation({
      lat: Number(lat.toFixed(4)),
      lng: Number(lng.toFixed(4)),
      address: minD < 1.5 ? closestArea.address : `Near ${closestArea.address}`,
    });
  };

  // Convert radiusKm to approximate SVG percentage radius
  const radiusSvgPct =
    radiusKm >= 50 ? 45 : Math.min(44, Math.max(8, (radiusKm / (10 / zoom)) * 32));

  return (
    <div className="bg-white border border-stone-200/80 rounded-2xl overflow-hidden">
      {/* Top Map Control Bar */}
      <div className="px-4 py-3 border-b border-stone-200/80 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <Compass className="w-4 h-4 text-emerald-800 shrink-0" />
          <div className="truncate">
            <span className="text-xs text-stone-500">Current Point · </span>
            <span className="text-xs font-semibold text-stone-900">
              {userLocation.address}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Radius Filter Buttons */}
          {!pickerMode && (
            <div
              className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg"
              role="group"
              aria-label="Search radius"
            >
              {[2, 5, 10, 25, 100].map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => onChangeRadiusKm(r)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap min-h-[32px] tabular-nums ${
                    radiusKm === r
                      ? 'bg-stone-900 text-white'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  {r === 100 ? 'All KM' : `${r} KM`}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={handleDetectGps}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-emerald-900 text-white rounded-lg hover:bg-emerald-800 transition-colors whitespace-nowrap min-h-[36px]"
          >
            <LocateFixed className="w-3.5 h-3.5" />
            <span>Detect GPS</span>
          </button>
        </div>
      </div>

      {/* Interactive SVG Map Canvas */}
      <div
        className={`relative w-full ${
          compact ? 'h-64 sm:h-72' : 'h-80 sm:h-[420px]'
        } bg-[#EDEFE9] select-none overflow-hidden`}
      >
        <svg
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
          onClick={handleMapSvgClick}
          className={`w-full h-full ${pickerMode ? 'cursor-crosshair' : 'cursor-grab'}`}
        >
          {/* Subtle topographic grid */}
          <defs>
            <pattern id="hk-grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path
                d="M 10 0 L 0 0 0 10"
                fill="none"
                stroke="#DDE2D6"
                strokeWidth="0.25"
              />
            </pattern>
          </defs>
          <rect width="100" height="100" fill="url(#hk-grid)" />

          {/* Green parks / zones */}
          <ellipse cx="26" cy="30" rx="12" ry="8" fill="#DFEAD8" opacity="0.7" />
          <ellipse cx="75" cy="72" rx="15" ry="10" fill="#DFEAD8" opacity="0.7" />
          <ellipse cx="48" cy="84" rx="14" ry="7" fill="#DFEAD8" opacity="0.6" />

          {/* Bagmati & Bishnumati Rivers */}
          <path
            d="M 88 12 Q 62 42 50 56 T 28 96"
            fill="none"
            stroke="#B8D4E3"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
          <path
            d="M 32 8 Q 38 38 50 56"
            fill="none"
            stroke="#B8D4E3"
            strokeWidth="1.1"
            strokeLinecap="round"
          />

          {/* Kathmandu Ring Road & Arterials */}
          <ellipse
            cx="50"
            cy="52"
            rx={33 * zoom}
            ry={35 * zoom}
            fill="none"
            stroke="#D6CFC2"
            strokeWidth="1.2"
          />
          <path
            d="M 5 52 L 95 52 M 50 5 L 50 95 M 18 22 L 84 82"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="0.8"
          />

          {/* Radius Circle around User Location */}
          {!pickerMode && radiusKm < 100 && (
            <circle
              cx={userPos.x}
              cy={userPos.y}
              r={radiusSvgPct}
              fill="rgba(6, 95, 70, 0.07)"
              stroke="#065F46"
              strokeWidth="0.35"
              strokeDasharray="1.2 1.2"
            />
          )}

          {/* Active Navigation Route Polyline */}
          {navDestPos && (
            <g>
              <path
                d={`M ${userPos.x} ${userPos.y} Q ${(userPos.x + navDestPos.x) / 2} ${
                  Math.min(userPos.y, navDestPos.y) - 6
                } ${navDestPos.x} ${navDestPos.y}`}
                fill="none"
                stroke="#065F46"
                strokeWidth="1.1"
                strokeDasharray="1.5 1"
              />
              <circle cx={navDestPos.x} cy={navDestPos.y} r="2.2" fill="#065F46" />
            </g>
          )}
        </svg>

        {/* Neighborhood Watermark Labels (Readable Geographical Landmarks) */}
        <div className="pointer-events-none absolute inset-0">
          {KATHMANDU_LOCATIONS.slice(0, 6).map((loc) => {
            const pt = projectPoint(loc);
            const shortName = loc.address.split(',')[0];
            return (
              <span
                key={loc.address}
                style={{ left: `${pt.x}%`, top: `${pt.y}%` }}
                className="absolute -translate-x-1/2 -translate-y-1/2 text-[10px] font-medium text-stone-500/80 bg-white/60 px-1.5 py-0.5 rounded whitespace-nowrap"
              >
                {shortName}
              </span>
            );
          })}
        </div>

        {/* User Current Location Pin */}
        <div
          style={{ left: `${userPos.x}%`, top: `${userPos.y}%` }}
          className="absolute -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none"
        >
          <div className="relative flex items-center justify-center">
            {liveLocationSharing && (
              <span className="animate-ping absolute inline-flex h-7 w-7 rounded-full bg-emerald-600 opacity-35" />
            )}
            <div className="w-4 h-4 rounded-full bg-emerald-800 border-2 border-white shadow-md" />
          </div>
          <div className="mt-1 px-1.5 py-0.5 bg-stone-900 text-white text-[10px] font-medium rounded whitespace-nowrap shadow">
            You
          </div>
        </div>

        {/* Nearby Scrap Listing Pins */}
        {!pickerMode &&
          listings.map((item) => {
            const pos = projectPoint(item.location);
            const dist = calculateDistanceKm(userLocation, item.location);
            const isSelected = selectedListingId === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectListing(item)}
                style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 z-10 group transition-transform ${
                  isSelected ? 'scale-110 z-30' : 'hover:scale-105'
                }`}
                title={`${item.title} (${dist} KM)`}
              >
                <div
                  className={`flex items-center gap-1 px-2 py-1 rounded-lg shadow-md text-xs font-medium whitespace-nowrap transition-colors ${
                    isSelected
                      ? 'bg-emerald-900 text-white ring-2 ring-white'
                      : 'bg-white text-stone-900 border border-stone-300 hover:border-stone-900'
                  }`}
                >
                  <MapPin className="w-3 h-3 shrink-0 text-emerald-700 group-hover:text-emerald-800" />
                  <span>{item.category}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {formatRs(item.askingPricePerKg)}/KG
                  </span>
                </div>
              </button>
            );
          })}

        {/* Zoom Controls */}
        <div className="absolute right-3 bottom-3 flex flex-col gap-1 z-20">
          <button
            type="button"
            onClick={() => setZoom((z) => Math.min(1.8, Number((z + 0.2).toFixed(1))))}
            aria-label="Zoom in"
            className="w-9 h-9 bg-white border border-stone-200 rounded-lg flex items-center justify-center text-stone-700 hover:bg-stone-50 shadow-sm"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setZoom((z) => Math.max(0.8, Number((z - 0.2).toFixed(1))))}
            aria-label="Zoom out"
            className="w-9 h-9 bg-white border border-stone-200 rounded-lg flex items-center justify-center text-stone-700 hover:bg-stone-50 shadow-sm"
          >
            <Minus className="w-4 h-4" />
          </button>
        </div>

        {/* GPS Feedback Overlay */}
        {gpsStatus && (
          <div className="absolute left-3 top-3 bg-stone-900/90 text-white text-xs px-3 py-1.5 rounded-lg z-30">
            {gpsStatus}
          </div>
        )}
      </div>

      {/* Turn-by-Turn Navigation Banner when active */}
      {navigationTarget && (
        <div className="px-4 py-3 bg-emerald-950 text-white flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Truck className="w-5 h-5 text-emerald-300 shrink-0" />
            <div>
              <div className="text-xs font-semibold">
                Navigation to {navigationTarget.title} ({navigationTarget.destination.address})
              </div>
              <div className="text-xs text-emerald-200 font-mono tabular-nums">
                Distance: {navDistanceKm} KM · Est. travel: {estimatedDriveMins} mins via Ring Road / City Arterial
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href={`https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&route=${userLocation.lat}%2C${userLocation.lng}%3B${navigationTarget.destination.lat}%2C${navigationTarget.destination.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white text-emerald-950 rounded-lg hover:bg-emerald-50 transition-colors whitespace-nowrap"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Turn-by-Turn Route</span>
            </a>
            {onClearNavigation && (
              <button
                type="button"
                onClick={onClearNavigation}
                className="px-2.5 py-1.5 text-xs text-emerald-200 hover:text-white"
              >
                Close
              </button>
            )}
          </div>
        </div>
      )}

      {/* Bottom Privacy & Quick Area Bar */}
      <div className="px-4 py-2.5 bg-stone-50 border-t border-stone-200/70 flex flex-wrap items-center justify-between gap-3 text-xs text-stone-600">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-800 shrink-0" />
          <span>
            {liveLocationSharing
              ? 'Live location sharing enabled for active pickup'
              : 'Privacy protected: continuous live tracking is off'}
          </span>
          <button
            type="button"
            onClick={() => onToggleLiveSharing(!liveLocationSharing)}
            className="underline font-medium text-stone-900 hover:text-emerald-800 ml-1 whitespace-nowrap"
          >
            {liveLocationSharing ? 'Disable Live Sharing' : 'Enable Live Sharing'}
          </button>
        </div>

        <div className="flex items-center gap-2">
          <label htmlFor="quick-area-select" className="text-stone-500 whitespace-nowrap">
            Switch Area:
          </label>
          <select
            id="quick-area-select"
            value={userLocation.address}
            onChange={(e) => {
              const found = KATHMANDU_LOCATIONS.find((l) => l.address === e.target.value);
              if (found) {
                onUpdateUserLocation(found, true);
                if (pickerMode && onPickLocation) onPickLocation(found);
              }
            }}
            className="bg-white border border-stone-300 rounded-md px-2 py-1 text-xs text-stone-900 focus:outline-none focus:border-stone-900"
          >
            {KATHMANDU_LOCATIONS.map((loc) => (
              <option key={loc.address} value={loc.address}>
                {loc.address}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
