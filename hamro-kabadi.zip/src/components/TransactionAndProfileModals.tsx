import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  MapPin,
  Navigation,
  Phone,
  ShieldCheck,
  Star,
  Truck,
  Upload,
  X,
  XCircle,
} from 'lucide-react';
import {
  GeoPoint,
  ScrapTransaction,
  TransactionStatus,
  UserAccount,
  UserReview,
} from '../types';
import { formatRs, KATHMANDU_LOCATIONS } from '../utils/cryptoAndGeo';
import { ResilientImage } from './ResilientImage';

const STATUS_SEQUENCE: TransactionStatus[] = [
  TransactionStatus.PENDING,
  TransactionStatus.NEGOTIATING,
  TransactionStatus.CONFIRMED,
  TransactionStatus.PICKED_UP,
  TransactionStatus.COMPLETED,
];

interface TransactionsViewProps {
  transactions: ScrapTransaction[];
  currentUser: UserAccount;
  onUpdateStatus: (transactionId: string, nextStatus: TransactionStatus) => void;
  onCancelTransaction: (transactionId: string, reason: string) => void;
  onSubmitReview: (
    transaction: ScrapTransaction,
    rating: number,
    comment: string
  ) => void;
  onNavigateToPickup: (title: string, destination: GeoPoint) => void;
  onViewProfile: (userId: string) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  transactions,
  currentUser,
  onUpdateStatus,
  onCancelTransaction,
  onSubmitReview,
  onNavigateToPickup,
  onViewProfile,
}) => {
  const [reviewingTxn, setReviewingTxn] = useState<ScrapTransaction | null>(null);
  const [ratingVal, setRatingVal] = useState<number>(5);
  const [reviewComment, setReviewComment] = useState<string>('');
  const [cancellingTxnId, setCancellingTxnId] = useState<string | null>(null);
  const [cancelReason, setCancelReason] = useState<string>('');

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewingTxn) return;
    onSubmitReview(
      reviewingTxn,
      ratingVal,
      reviewComment.trim() || 'Smooth pickup and accurate digital weighing.'
    );
    setReviewingTxn(null);
    setReviewComment('');
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-stone-200/80 pb-4">
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-900">
          Transaction Ledger & Pickup Status
        </h1>
        <p className="text-sm text-stone-600 mt-1">
          Track every deal from Pending → Negotiating → Confirmed → Picked Up → Completed.
          Either party may cancel prior to completion.
        </p>
      </div>

      {transactions.length === 0 ? (
        <div className="bg-white border border-stone-200 rounded-2xl p-8 text-center text-sm text-stone-600">
          No transactions recorded yet. Agree on a final price in a listing or chat to generate a
          transaction record.
        </div>
      ) : (
        <div className="space-y-4">
          {transactions.map((txn) => {
            const currentStageIdx = STATUS_SEQUENCE.indexOf(txn.status);
            const isTerminal =
              txn.status === TransactionStatus.COMPLETED ||
              txn.status === TransactionStatus.CANCELLED;

            const nextStatus =
              currentStageIdx >= 0 && currentStageIdx < STATUS_SEQUENCE.length - 1
                ? STATUS_SEQUENCE[currentStageIdx + 1]
                : null;

            return (
              <div
                key={txn.id}
                className="bg-white border border-stone-200/90 rounded-2xl p-5 sm:p-6 space-y-4"
              >
                {/* Top Summary Row */}
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <div className="text-xs text-stone-500 font-mono tabular-nums">
                      Transaction {txn.id} · {new Date(txn.createdAt).toLocaleDateString()} ·{' '}
                      {txn.scheduledPickupTime || 'Flexible Pickup'}
                    </div>
                    <h2 className="font-display text-xl font-bold text-stone-900 mt-0.5">
                      {txn.listingTitle} ({txn.category})
                    </h2>
                    <div className="text-xs text-stone-600 mt-1 flex flex-wrap items-center gap-1.5">
                      <span>
                        Buyer:{' '}
                        <button
                          type="button"
                          onClick={() => onViewProfile(txn.buyerId)}
                          className="font-semibold text-stone-900 underline hover:text-emerald-800"
                        >
                          {txn.buyerName}
                        </button>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Seller:{' '}
                        <button
                          type="button"
                          onClick={() => onViewProfile(txn.sellerId)}
                          className="font-semibold text-stone-900 underline hover:text-emerald-800"
                        >
                          {txn.sellerName}
                        </button>
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Location: {txn.pickupLocation.address}</span>
                    </div>
                  </div>

                  <div className="text-right font-mono tabular-nums">
                    <div className="text-lg font-bold text-stone-900">
                      {formatRs(txn.totalAgreedAmount)}
                    </div>
                    <div className="text-xs text-stone-500">
                      {txn.weightKg} KG × {formatRs(txn.agreedPricePerKg)}/KG
                    </div>
                  </div>
                </div>

                {/* 5-Stage Status Stepper (No Hue-Only Signaling: Icon + Explicit Label) */}
                {txn.status === TransactionStatus.CANCELLED ? (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-900 flex items-center gap-2">
                    <XCircle className="w-4 h-4 text-red-700 shrink-0" />
                    <span>
                      <strong>Status: Cancelled</strong> · Cancelled by {txn.cancelledBy || 'User'}{' '}
                      {txn.cancelReason ? `(${txn.cancelReason})` : ''}
                    </span>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2">
                    {STATUS_SEQUENCE.map((step, idx) => {
                      const done = idx <= currentStageIdx;
                      return (
                        <div
                          key={step}
                          className={`p-2.5 rounded-xl border text-xs flex items-center gap-2 ${
                            done
                              ? 'bg-emerald-50/70 border-emerald-800 text-emerald-950 font-semibold'
                              : 'bg-stone-50 border-stone-200 text-stone-500'
                          }`}
                        >
                          {done ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-800 shrink-0" />
                          ) : (
                            <Clock className="w-4 h-4 text-stone-400 shrink-0" />
                          )}
                          <span className="truncate">
                            {idx + 1}. {step}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Action Bar */}
                <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      onNavigateToPickup(txn.listingTitle, txn.pickupLocation)
                    }
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-900 hover:underline"
                  >
                    <Navigation className="w-3.5 h-3.5" />
                    <span>Directions to Pickup ({txn.pickupLocation.address})</span>
                  </button>

                  <div className="flex flex-wrap items-center gap-2">
                    {!isTerminal && nextStatus && (
                      <button
                        type="button"
                        onClick={() => onUpdateStatus(txn.id, nextStatus)}
                        className="px-3.5 py-2 text-xs font-semibold bg-emerald-900 hover:bg-emerald-800 text-white rounded-xl transition-colors min-h-[38px]"
                      >
                        Advance to &ldquo;{nextStatus}&rdquo;
                      </button>
                    )}

                    {!isTerminal && (
                      <button
                        type="button"
                        onClick={() => setCancellingTxnId(txn.id)}
                        className="px-3 py-2 text-xs font-medium bg-stone-100 hover:bg-red-50 hover:text-red-800 text-stone-700 rounded-xl transition-colors min-h-[38px]"
                      >
                        Cancel Transaction
                      </button>
                    )}

                    {txn.status === TransactionStatus.COMPLETED && (
                      <button
                        type="button"
                        onClick={() => {
                          setReviewingTxn(txn);
                          setRatingVal(5);
                        }}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-white rounded-xl min-h-[38px]"
                      >
                        <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                        <span>Rate &amp; Review Counterparty</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Inline Cancel Confirmation */}
                {cancellingTxnId === txn.id && (
                  <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-xl flex flex-wrap items-center justify-between gap-3">
                    <input
                      type="text"
                      value={cancelReason}
                      onChange={(e) => setCancelReason(e.target.value)}
                      placeholder="Reason for cancellation (e.g. schedule change)..."
                      className="flex-1 px-3 py-1.5 text-xs bg-white border border-stone-300 rounded-lg"
                    />
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          onCancelTransaction(
                            txn.id,
                            cancelReason.trim() || 'Cancelled before completion'
                          );
                          setCancellingTxnId(null);
                          setCancelReason('');
                        }}
                        className="px-3 py-1.5 text-xs font-semibold bg-red-700 text-white rounded-lg"
                      >
                        Confirm Cancel
                      </button>
                      <button
                        type="button"
                        onClick={() => setCancellingTxnId(null)}
                        className="px-2.5 py-1.5 text-xs text-stone-600"
                      >
                        Keep Active
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Rate & Review Modal */}
      {reviewingTxn && (
        <div
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white border border-stone-200 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-bold text-stone-900">
                Rate &amp; Review Transaction
              </h3>
              <button
                type="button"
                onClick={() => setReviewingTxn(null)}
                className="w-8 h-8 rounded-lg bg-stone-100 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-stone-600">
              Share your experience for <strong>{reviewingTxn.listingTitle}</strong> with{' '}
              <strong>
                {currentUser.id === reviewingTxn.buyerId
                  ? reviewingTxn.sellerName
                  : reviewingTxn.buyerName}
              </strong>
              .
            </p>

            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1.5">
                  Select Star Rating
                </label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setRatingVal(star)}
                      className={`w-10 h-10 rounded-xl border flex items-center justify-center font-mono text-xs font-bold ${
                        ratingVal >= star
                          ? 'bg-amber-50 border-amber-400 text-amber-900'
                          : 'bg-stone-50 border-stone-200 text-stone-400'
                      }`}
                    >
                      {star}★
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1.5">
                  Written Review
                </label>
                <textarea
                  rows={3}
                  required
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  placeholder="How was the material quality, weighing accuracy, and pickup?"
                  className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-300 rounded-xl"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-900 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl min-h-[44px]"
              >
                Submit Review
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

interface ProfileModalProps {
  profileUser: UserAccount | null;
  reviews: UserReview[];
  isOwnProfile: boolean;
  onClose: () => void;
  onSaveProfile: (updated: UserAccount) => void;
}

export const UserProfileModal: React.FC<ProfileModalProps> = ({
  profileUser,
  reviews,
  isOwnProfile,
  onClose,
  onSaveProfile,
}) => {
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState(profileUser?.fullName || '');
  const [phone, setPhone] = useState(profileUser?.phone || '');
  const [photo, setPhoto] = useState(profileUser?.profilePhoto || '');
  const [address, setAddress] = useState(profileUser?.location.address || '');

  if (!profileUser) return null;

  const userReviews = reviews.filter((r) => r.targetUserId === profileUser.id);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setPhoto(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const matchedLoc =
      KATHMANDU_LOCATIONS.find((l) => l.address === address) || {
        ...profileUser.location,
        address,
      };
    onSaveProfile({
      ...profileUser,
      fullName: fullName.trim() || profileUser.fullName,
      phone: phone.trim() || profileUser.phone,
      profilePhoto: photo || profileUser.profilePhoto,
      location: matchedLoc,
    });
    setEditing(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="bg-white border border-stone-200 rounded-3xl max-w-lg w-full p-6 sm:p-8 space-y-6 shadow-xl my-8">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl overflow-hidden border border-stone-200 shrink-0">
              <ResilientImage
                src={editing ? photo : profileUser.profilePhoto}
                alt={profileUser.fullName}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display text-xl font-bold text-stone-900">
                  {profileUser.fullName}
                </h2>
                {profileUser.verifiedBadge && (
                  <ShieldCheck
                    className="w-4 h-4 text-emerald-800 shrink-0"
                    title="Verified Trader Badge"
                  />
                )}
              </div>
              <div className="text-xs text-stone-500 mt-0.5">
                {profileUser.role} · ID: <span className="font-mono">{profileUser.id}</span> (@
                {profileUser.userId})
              </div>
              <div className="text-xs text-stone-600 mt-1">
                Phone Verified: {profileUser.phoneVerified ? 'Yes' : 'Pending'} · Joined{' '}
                {profileUser.createdAt}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Clean Unboxed Reputation Metrics */}
        <div className="grid grid-cols-3 gap-4 py-3.5 border-y border-stone-200/80 text-center">
          <div>
            <div className="font-mono tabular-nums text-lg font-bold text-stone-900">
              ★ {profileUser.rating.toFixed(1)}
            </div>
            <div className="text-xs text-stone-500">
              Rating ({profileUser.reviewCount} reviews)
            </div>
          </div>
          <div>
            <div className="font-mono tabular-nums text-lg font-bold text-stone-900">
              {profileUser.completedTransactions}
            </div>
            <div className="text-xs text-stone-500">Completed Deals</div>
          </div>
          <div>
            <div className="font-mono tabular-nums text-sm font-semibold text-emerald-900 truncate px-1">
              {profileUser.verifiedBadge ? 'Verified Badge' : 'Standard'}
            </div>
            <div className="text-xs text-stone-500">Trust Status</div>
          </div>
        </div>

        {editing ? (
          <form onSubmit={handleSave} className="space-y-4">
            <div className="flex items-center gap-3">
              <label
                htmlFor="edit-profile-photo"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-stone-100 hover:bg-stone-200 rounded-lg cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload New Photo</span>
              </label>
              <input
                id="edit-profile-photo"
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-300 rounded-xl"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Phone Number
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-300 rounded-xl font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">
                Primary Location
              </label>
              <select
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-300 rounded-xl"
              >
                {KATHMANDU_LOCATIONS.map((loc) => (
                  <option key={loc.address} value={loc.address}>
                    {loc.address}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="px-4 py-2 text-xs font-medium text-stone-600"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold bg-emerald-900 text-white rounded-xl"
              >
                Save Profile
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-4">
            <div className="text-xs text-stone-600 space-y-1.5">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-stone-400" />
                <span>Location: {profileUser.location.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-stone-400" />
                <span className="font-mono">{profileUser.phone}</span>
              </div>
            </div>

            {/* Reviews Section */}
            <div className="space-y-2.5 pt-2">
              <h3 className="text-xs font-semibold text-stone-900">
                Recent Trader Reviews ({userReviews.length})
              </h3>
              {userReviews.length === 0 ? (
                <p className="text-xs text-stone-500">No reviews posted yet.</p>
              ) : (
                <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                  {userReviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="p-3 rounded-xl bg-stone-50 border border-stone-200/70 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-stone-900">
                          {rev.reviewerName} ({rev.reviewerRole})
                        </span>
                        <span className="font-mono tabular-nums text-amber-800 font-semibold">
                          ★ {rev.rating.toFixed(1)} · {rev.createdAt}
                        </span>
                      </div>
                      <p className="text-stone-600">{rev.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {isOwnProfile && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setFullName(profileUser.fullName);
                    setPhone(profileUser.phone);
                    setPhoto(profileUser.profilePhoto);
                    setAddress(profileUser.location.address);
                    setEditing(true);
                  }}
                  className="w-full py-2.5 text-xs font-semibold bg-stone-900 hover:bg-stone-800 text-white rounded-xl min-h-[42px]"
                >
                  Edit Profile &amp; Photo
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
