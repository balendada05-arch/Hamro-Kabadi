import React, { useState } from 'react';
import {
  CheckCircle2,
  Handshake,
  Image as ImageIcon,
  MapPin,
  PhoneCall,
  Send,
  UserCheck,
} from 'lucide-react';
import {
  ChatMessage,
  ChatThread,
  GeoPoint,
  UserAccount,
  UserRole,
} from '../types';
import { formatRs } from '../utils/cryptoAndGeo';

interface ChatAndNegotiationProps {
  threads: ChatThread[];
  messages: ChatMessage[];
  currentUser: UserAccount;
  selectedThreadId: string | null;
  onSelectThread: (threadId: string) => void;
  onSendMessage: (
    threadId: string,
    text: string,
    options?: {
      photoUrl?: string;
      offeredPricePerKg?: number;
      sharedLocation?: GeoPoint;
      isFinalConfirmation?: boolean;
    }
  ) => void;
  onConfirmFinalPrice: (thread: ChatThread, agreedPricePerKg: number) => void;
  onOpenCallModal: (name: string, phone: string, roleLabel: string) => void;
  onViewProfile: (userId: string) => void;
}

export const ChatAndNegotiation: React.FC<ChatAndNegotiationProps> = ({
  threads,
  messages,
  currentUser,
  selectedThreadId,
  onSelectThread,
  onSendMessage,
  onConfirmFinalPrice,
  onOpenCallModal,
  onViewProfile,
}) => {
  const activeThread =
    threads.find((t) => t.id === selectedThreadId) || threads[0] || null;

  const [messageText, setMessageText] = useState('');
  const [offerInput, setOfferInput] = useState<string>('');
  const [showOfferBox, setShowOfferBox] = useState(false);

  const threadMessages = activeThread
    ? messages.filter((m) => m.threadId === activeThread.id)
    : [];

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeThread || !messageText.trim()) return;
    onSendMessage(activeThread.id, messageText.trim());
    setMessageText('');
  };

  const handleSendPriceOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeThread) return;
    const price = Number(offerInput);
    if (!price || price <= 0) return;
    const total = Math.round(price * activeThread.listingWeightKg);
    onSendMessage(
      activeThread.id,
      `Proposed price offer: ${formatRs(price)}/KG (Total: ${formatRs(total)} for ${
        activeThread.listingWeightKg
      } KG).`,
      { offeredPricePerKg: price }
    );
    setOfferInput('');
    setShowOfferBox(false);
  };

  const handleShareLocation = () => {
    if (!activeThread) return;
    onSendMessage(
      activeThread.id,
      `Shared pickup location: ${currentUser.location.address}`,
      { sharedLocation: currentUser.location }
    );
  };

  const handleAttachPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeThread) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onSendMessage(activeThread.id, 'Attached material photo for inspection.', {
          photoUrl: reader.result,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  if (threads.length === 0) {
    return (
      <div className="bg-white border border-stone-200/90 rounded-2xl p-10 text-center space-y-2">
        <h2 className="font-display text-xl font-bold text-stone-900">
          No Active Conversations Yet
        </h2>
        <p className="text-sm text-stone-600 max-w-md mx-auto">
          Select any scrap listing from the Marketplace and click &ldquo;Chat &amp;
          Negotiate&rdquo; to discuss rates, share photos, or confirm pickup.
        </p>
      </div>
    );
  }

  const counterpartName =
    activeThread && currentUser.id === activeThread.buyerId
      ? activeThread.sellerName
      : activeThread?.buyerName || '';
  const counterpartPhone =
    activeThread && currentUser.id === activeThread.buyerId
      ? activeThread.sellerPhone
      : activeThread?.buyerPhone || '';
  const counterpartId =
    activeThread && currentUser.id === activeThread.buyerId
      ? activeThread.sellerId
      : activeThread?.buyerId || '';
  const counterpartRoleLabel =
    activeThread && currentUser.id === activeThread.buyerId ? 'Seller' : 'Buyer';

  const latestOfferedPrice =
    [...threadMessages].reverse().find((m) => m.offeredPricePerKg)?.offeredPricePerKg ||
    activeThread?.currentAgreedPricePerKg ||
    activeThread?.listingAskingPricePerKg ||
    40;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left Thread List */}
      <div className="lg:col-span-4 bg-white border border-stone-200/90 rounded-2xl overflow-hidden">
        <div className="px-4 py-3.5 border-b border-stone-200 bg-stone-50/70">
          <h2 className="font-display text-base font-bold text-stone-900">
            Negotiations & Messages
          </h2>
        </div>
        <div className="divide-y divide-stone-100">
          {threads.map((t) => {
            const isSelected = activeThread?.id === t.id;
            const otherParty =
              currentUser.id === t.buyerId ? t.sellerName : t.buyerName;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => onSelectThread(t.id)}
                className={`w-full text-left p-4 transition-colors ${
                  isSelected ? 'bg-emerald-50/70' : 'hover:bg-stone-50'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-sm text-stone-900 truncate">
                    {t.listingTitle}
                  </span>
                  <span className="font-mono tabular-nums text-xs font-semibold text-emerald-900 shrink-0">
                    {formatRs(t.currentAgreedPricePerKg || t.listingAskingPricePerKg)}/KG
                  </span>
                </div>
                <div className="text-xs text-stone-500 mt-1 flex items-center gap-1.5">
                  <span>{otherParty}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{t.listingWeightKg} KG</span>
                  <span aria-hidden="true">·</span>
                  <span className="truncate">{t.pickupLocation.address}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Right Active Conversation & Price Negotiation Workspace */}
      {activeThread && (
        <div className="lg:col-span-8 bg-white border border-stone-200/90 rounded-2xl overflow-hidden flex flex-col">
          {/* Conversation Header */}
          <div className="p-4 border-b border-stone-200 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display text-lg font-bold text-stone-900">
                  {activeThread.listingTitle}
                </h3>
                <span className="text-xs text-stone-500 font-mono tabular-nums">
                  · {activeThread.listingWeightKg} KG
                </span>
              </div>
              <div className="text-xs text-stone-600 flex flex-wrap items-center gap-1.5 mt-0.5">
                <span>
                  {counterpartRoleLabel}: <strong>{counterpartName}</strong>
                </span>
                <span aria-hidden="true">·</span>
                <button
                  type="button"
                  onClick={() => onViewProfile(counterpartId)}
                  className="inline-flex items-center gap-1 text-emerald-800 font-medium hover:underline"
                >
                  <UserCheck className="w-3.5 h-3.5" />
                  <span>View {counterpartRoleLabel} Profile</span>
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  onOpenCallModal(counterpartName, counterpartPhone, counterpartRoleLabel)
                }
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-900 rounded-xl transition-colors min-h-[40px]"
              >
                <PhoneCall className="w-3.5 h-3.5 text-emerald-800" />
                <span>Call {counterpartRoleLabel}</span>
              </button>

              <button
                type="button"
                onClick={() => onConfirmFinalPrice(activeThread, latestOfferedPrice)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold bg-emerald-900 hover:bg-emerald-800 text-white rounded-xl transition-colors min-h-[40px]"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  Confirm Final Price ({formatRs(latestOfferedPrice)}/KG)
                </span>
              </button>
            </div>
          </div>

          {/* Negotiation Bar */}
          <div className="px-4 py-2.5 bg-stone-50 border-b border-stone-200/80 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div className="text-stone-600 font-mono tabular-nums">
              Asking: <strong>{formatRs(activeThread.listingAskingPricePerKg)}/KG</strong> ·
              Latest Offer: <strong className="text-emerald-900">{formatRs(latestOfferedPrice)}/KG</strong>{' '}
              (Total: {formatRs(Math.round(latestOfferedPrice * activeThread.listingWeightKg))})
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setOfferInput(String(latestOfferedPrice));
                  setShowOfferBox(!showOfferBox);
                }}
                className="inline-flex items-center gap-1 px-2.5 py-1 font-semibold bg-white border border-stone-300 hover:border-stone-900 rounded-lg text-stone-900"
              >
                <Handshake className="w-3.5 h-3.5 text-emerald-800" />
                <span>Negotiate Price</span>
              </button>
              <button
                type="button"
                onClick={handleShareLocation}
                className="inline-flex items-center gap-1 px-2.5 py-1 font-medium bg-white border border-stone-300 hover:border-stone-900 rounded-lg text-stone-800"
              >
                <MapPin className="w-3.5 h-3.5 text-emerald-800" />
                <span>Share Pickup Location</span>
              </button>
            </div>
          </div>

          {/* Collapsible Offer Input Drawer */}
          {showOfferBox && (
            <form
              onSubmit={handleSendPriceOffer}
              className="p-3.5 bg-emerald-50/80 border-b border-emerald-200 flex flex-wrap items-center justify-between gap-3"
            >
              <div className="flex items-center gap-2">
                <label className="text-xs font-semibold text-emerald-950">
                  Your Offer (Rs./KG):
                </label>
                <input
                  type="number"
                  min={1}
                  required
                  value={offerInput}
                  onChange={(e) => setOfferInput(e.target.value)}
                  className="w-28 px-2.5 py-1.5 text-xs font-mono bg-white border border-emerald-300 rounded-lg"
                />
                {Number(offerInput) > 0 && (
                  <span className="text-xs font-mono tabular-nums text-emerald-900">
                    = {formatRs(Math.round(Number(offerInput) * activeThread.listingWeightKg))}{' '}
                    total
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="submit"
                  className="px-3 py-1.5 text-xs font-semibold bg-emerald-900 text-white rounded-lg hover:bg-emerald-800"
                >
                  Send Offer
                </button>
                <button
                  type="button"
                  onClick={() => setShowOfferBox(false)}
                  className="px-2.5 py-1.5 text-xs text-stone-600 hover:text-stone-900"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* Message Feed */}
          <div className="p-4 space-y-3.5 max-h-[380px] overflow-y-auto bg-[#FAFBF9]">
            {threadMessages.map((msg) => {
              const isMe = msg.senderId === currentUser.id;
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                >
                  <div className="text-[11px] text-stone-500 mb-1 px-1">
                    {msg.senderName} · {msg.senderRole}
                  </div>
                  <div
                    className={`max-w-md rounded-2xl px-4 py-2.5 text-sm space-y-2 ${
                      isMe
                        ? 'bg-emerald-900 text-white'
                        : 'bg-white border border-stone-200 text-stone-900'
                    }`}
                  >
                    <p>{msg.text}</p>

                    {msg.offeredPricePerKg && (
                      <div
                        className={`p-2.5 rounded-xl text-xs font-mono tabular-nums flex items-center justify-between gap-3 ${
                          isMe
                            ? 'bg-emerald-950/80 text-emerald-100'
                            : 'bg-stone-100 text-stone-900'
                        }`}
                      >
                        <span>
                          Offer: <strong>{formatRs(msg.offeredPricePerKg)}/KG</strong> · Total:{' '}
                          {formatRs(
                            Math.round(msg.offeredPricePerKg * activeThread.listingWeightKg)
                          )}
                        </span>
                        {!isMe && (
                          <button
                            type="button"
                            onClick={() =>
                              onConfirmFinalPrice(activeThread, msg.offeredPricePerKg!)
                            }
                            className="px-2.5 py-1 bg-emerald-800 text-white rounded-lg font-sans font-semibold hover:bg-emerald-700"
                          >
                            Accept & Confirm
                          </button>
                        )}
                      </div>
                    )}

                    {msg.sharedLocation && (
                      <div
                        className={`p-2 rounded-xl text-xs flex items-center gap-2 ${
                          isMe ? 'bg-emerald-950/60 text-emerald-100' : 'bg-stone-100 text-stone-800'
                        }`}
                      >
                        <MapPin className="w-3.5 h-3.5 shrink-0" />
                        <span>
                          Pickup Pin: {msg.sharedLocation.address} (
                          {msg.sharedLocation.lat.toFixed(3)}°N,{' '}
                          {msg.sharedLocation.lng.toFixed(3)}°E)
                        </span>
                      </div>
                    )}

                    {msg.photoUrl && (
                      <img
                        src={msg.photoUrl}
                        alt="Chat attachment"
                        referrerPolicy="no-referrer"
                        className="w-48 h-36 object-cover rounded-xl border border-white/20"
                      />
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Message Input Bar */}
          <form
            onSubmit={handleSendText}
            className="p-3 bg-white border-t border-stone-200 flex items-center gap-2"
          >
            <label
              htmlFor="chat-photo-upload"
              className="w-10 h-10 rounded-xl bg-stone-100 hover:bg-stone-200 flex items-center justify-center text-stone-700 cursor-pointer shrink-0"
              title="Send photo"
            >
              <ImageIcon className="w-4 h-4" />
            </label>
            <input
              id="chat-photo-upload"
              type="file"
              accept="image/*"
              onChange={handleAttachPhoto}
              className="hidden"
            />

            <input
              type="text"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Write a message, negotiate rate, or coordinate pickup..."
              className="flex-1 px-3.5 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:outline-none focus:border-emerald-900 min-h-[44px]"
            />

            <button
              type="submit"
              className="px-4 py-2.5 bg-emerald-900 hover:bg-emerald-800 text-white text-xs font-semibold rounded-xl inline-flex items-center gap-1.5 min-h-[44px] shrink-0"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
