import React, { useState } from 'react';
import { Package } from 'lucide-react';
import { MaterialCategory } from '../types';
import { getCategoryFallbackGradient } from '../utils/cryptoAndGeo';

interface ResilientImageProps {
  src: string;
  alt: string;
  category?: MaterialCategory;
  className?: string;
}

export const ResilientImage: React.FC<ResilientImageProps> = ({
  src,
  alt,
  category = MaterialCategory.IRON,
  className = 'w-full h-full object-cover',
}) => {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    const gradient = getCategoryFallbackGradient(category);
    return (
      <div
        className={`bg-gradient-to-br ${gradient} text-white flex flex-col items-center justify-center p-4 text-center select-none ${className}`}
        role="img"
        aria-label={alt}
      >
        <Package className="w-7 h-7 opacity-80 mb-1.5" />
        <span className="text-xs font-medium tracking-tight opacity-90 line-clamp-2">
          {alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
    />
  );
};
