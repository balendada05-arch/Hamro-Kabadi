import React, { useState } from 'react';
import { Check, Edit3, History, TrendingUp, X } from 'lucide-react';
import { MaterialCategory, MaterialPriceRate, UserRole } from '../types';
import { formatRs } from '../utils/cryptoAndGeo';

interface MarketPriceViewProps {
  rates: MaterialPriceRate[];
  currentUserRole: UserRole;
  onUpdateMarketRate: (
    category: MaterialCategory,
    marketPricePerKg: number,
    suggestedBuyingPrice: number,
    suggestedSellingPrice: number
  ) => void;
}

export const MarketPriceView: React.FC<MarketPriceViewProps> = ({
  rates,
  currentUserRole,
  onUpdateMarketRate,
}) => {
  const [selectedRate, setSelectedRate] = useState<MaterialPriceRate>(rates[0]);
  const [editingCategory, setEditingCategory] = useState<MaterialCategory | null>(null);
  const [adminModeEnabled, setAdminModeEnabled] = useState<boolean>(
    currentUserRole === UserRole.ADMIN
  );

  // Edit form values
  const [editMarket, setEditMarket] = useState<number>(50);
  const [editBuying, setEditBuying] = useState<number>(45);
  const [editSelling, setEditSelling] = useState<number>(40);

  const startEditing = (rate: MaterialPriceRate) => {
    setEditingCategory(rate.category);
    setEditMarket(rate.marketPricePerKg);
    setEditBuying(rate.suggestedBuyingPrice);
    setEditSelling(rate.suggestedSellingPrice);
  };

  const handleSaveRate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory) return;
    onUpdateMarketRate(
      editingCategory,
      Number(editMarket),
      Number(editBuying),
      Number(editSelling)
    );
    const updated = rates.find((r) => r.category === editingCategory);
    if (updated) {
      setSelectedRate({
        ...updated,
        marketPricePerKg: Number(editMarket),
        suggestedBuyingPrice: Number(editBuying),
        suggestedSellingPrice: Number(editSelling),
      });
    }
    setEditingCategory(null);
  };

  return (
    <div className="space-y-8">
      {/* Header & Admin Rate Controls */}
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-stone-200/80 pb-5">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-stone-900">
            Automatic Market Price Index
          </h1>
          <p className="text-sm text-stone-600 mt-1">
            Official daily per-KG benchmark prices, suggested seller asking rates, and buyer
            negotiation ranges across all 11 material categories.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setAdminModeEnabled(!adminModeEnabled)}
            className={`px-3.5 py-2 text-xs font-semibold rounded-xl border transition-colors min-h-[40px] ${
              adminModeEnabled
                ? 'bg-emerald-900 text-white border-emerald-900'
                : 'bg-white text-stone-800 border-stone-300 hover:border-stone-900'
            }`}
          >
            {adminModeEnabled ? 'Admin Price Editor Active' : 'Enable Admin Price Editor'}
          </button>
        </div>
      </div>

      {/* Main Grid: All 11 Material Rates Table + Selected Price History Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-8 bg-white border border-stone-200/90 rounded-2xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-stone-200 bg-stone-50/70 text-xs font-semibold text-stone-600">
                  <th className="py-3.5 px-4">Material</th>
                  <th className="py-3.5 px-4">Market Price</th>
                  <th className="py-3.5 px-4">Suggested Buying</th>
                  <th className="py-3.5 px-4">Suggested Seller</th>
                  <th className="py-3.5 px-4">Updated Date</th>
                  <th className="py-3.5 px-4 text-right">History / Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 text-sm">
                {rates.map((rate) => {
                  const isSelected = selectedRate.category === rate.category;
                  const isEditing = editingCategory === rate.category;

                  return (
                    <tr
                      key={rate.category}
                      onClick={() => setSelectedRate(rate)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-emerald-50/50' : 'hover:bg-stone-50'
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-stone-900">{rate.category}</div>
                        <div className="text-xs text-stone-500">{rate.nepaliName}</div>
                      </td>

                      <td className="py-3.5 px-4 font-mono tabular-nums font-semibold text-stone-900">
                        {isEditing ? (
                          <input
                            type="number"
                            min={1}
                            value={editMarket}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => {
                              const val = Number(e.target.value);
                              setEditMarket(val);
                              setEditBuying(Math.round(val * 0.9));
                              setEditSelling(Math.round(val * 0.8));
                            }}
                            className="w-20 px-2 py-1 text-xs border border-stone-300 rounded bg-white"
                          />
                        ) : (
                          `${formatRs(rate.marketPricePerKg)}/KG`
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono tabular-nums text-stone-700">
                        {isEditing ? (
                          <input
                            type="number"
                            min={1}
                            value={editBuying}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => setEditBuying(Number(e.target.value))}
                            className="w-20 px-2 py-1 text-xs border border-stone-300 rounded bg-white"
                          />
                        ) : (
                          `${formatRs(rate.suggestedBuyingPrice)}/KG`
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono tabular-nums text-emerald-900 font-medium">
                        {isEditing ? (
                          <input
                            type="number"
                            min={1}
                            value={editSelling}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => setEditSelling(Number(e.target.value))}
                            className="w-20 px-2 py-1 text-xs border border-stone-300 rounded bg-white"
                          />
                        ) : (
                          `${formatRs(rate.suggestedSellingPrice)}/KG`
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono tabular-nums text-xs text-stone-500">
                        {rate.updatedAt}
                      </td>

                      <td
                        className="py-3.5 px-4 text-right whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {isEditing ? (
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={handleSaveRate}
                              className="p-1.5 bg-emerald-900 text-white rounded-lg hover:bg-emerald-800"
                              title="Save rate"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingCategory(null)}
                              className="p-1.5 bg-stone-200 text-stone-700 rounded-lg hover:bg-stone-300"
                              title="Cancel"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => setSelectedRate(rate)}
                              className="text-xs font-medium text-stone-600 hover:text-stone-900 underline"
                            >
                              History
                            </button>
                            {adminModeEnabled && (
                              <button
                                type="button"
                                onClick={() => startEditing(rate)}
                                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium bg-stone-100 hover:bg-stone-200 text-stone-900 rounded-lg"
                              >
                                <Edit3 className="w-3 h-3" />
                                <span>Update</span>
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Detail Panel: Selected Material Breakdown & Price History */}
        <div className="lg:col-span-4 bg-white border border-stone-200/90 rounded-2xl p-6 space-y-5">
          <div>
            <div className="text-xs text-stone-500">
              {selectedRate.nepaliName} · Updated {selectedRate.updatedAt}
            </div>
            <h2 className="font-display text-2xl font-bold text-stone-900 mt-0.5">
              {selectedRate.category} Pricing Guide
            </h2>
            <p className="text-xs text-stone-600 mt-1.5 leading-relaxed">
              {selectedRate.description}
            </p>
          </div>

          <div className="pt-3 border-t border-stone-100 space-y-2.5 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-stone-600">Market price:</span>
              <span className="font-mono tabular-nums font-bold text-stone-900">
                {formatRs(selectedRate.marketPricePerKg)}/KG
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-stone-600">Suggested buying price:</span>
              <span className="font-mono tabular-nums font-semibold text-stone-800">
                {formatRs(selectedRate.suggestedBuyingPrice)}/KG
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-stone-600">Suggested seller price:</span>
              <span className="font-mono tabular-nums font-semibold text-emerald-900">
                {formatRs(selectedRate.suggestedSellingPrice)}/KG
              </span>
            </div>
            <p className="text-xs text-stone-500 pt-1">
              Buyer can negotiate directly with seller based on scrap purity, sorting, and pickup
              weight.
            </p>
          </div>

          {/* Price History Log */}
          <div className="pt-4 border-t border-stone-200/80 space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-stone-900">
              <History className="w-4 h-4 text-emerald-800" />
              <span>Historical Price Log ({selectedRate.category})</span>
            </div>

            <div className="space-y-2">
              {selectedRate.history
                .slice()
                .reverse()
                .map((entry, idx) => (
                  <div
                    key={`${entry.date}-${idx}`}
                    className="flex items-center justify-between py-2 border-b border-stone-100 last:border-none text-xs"
                  >
                    <div>
                      <span className="font-mono tabular-nums text-stone-900 font-medium">
                        {entry.date}
                      </span>
                      <span aria-hidden="true" className="mx-1.5 text-stone-400">
                        ·
                      </span>
                      <span className="text-stone-500">by {entry.updatedBy}</span>
                    </div>
                    <div className="font-mono tabular-nums text-stone-800">
                      <span className="font-semibold">
                        {formatRs(entry.marketPricePerKg)}/KG
                      </span>
                      <span className="text-stone-400 ml-1.5">
                        (Seller: {formatRs(entry.suggestedSellingPrice)})
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          <div className="p-3.5 bg-stone-50 rounded-xl text-xs text-stone-600 flex items-start gap-2.5">
            <TrendingUp className="w-4 h-4 text-emerald-800 shrink-0 mt-0.5" />
            <span>
              When a Seller selects <strong>{selectedRate.category}</strong> while creating a
              listing, Hamro Kabadi automatically pre-fills the suggested seller price of{' '}
              <strong className="font-mono tabular-nums">
                {formatRs(selectedRate.suggestedSellingPrice)}/KG
              </strong>
              .
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
